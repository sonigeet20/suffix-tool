const express = require('express');
const puppeteer = require('puppeteer');
const axios = require('axios');
const { CookieJar } = require('tough-cookie');
const https = require('https');
const http = require('http');
const crypto = require('crypto');
const cors = require('cors');
const helmet = require('helmet');
const winston = require('winston');
const UserAgent = require('user-agents');
const { createClient } = require('@supabase/supabase-js');
const { HttpsProxyAgent } = require('https-proxy-agent');
const { traceRedirectsInteractive } = require('./trace-interactive');
const GeoRotator = require('./lib/geo-rotator');
const dns = require('dns').promises;
require('dotenv').config();

// Pre-import got at module level to avoid dynamic import overhead per hop
let gotModule = null;
(async () => {
  const { default: got } = await import('got');
  gotModule = got;
})();

const app = express();
const PORT = process.env.PORT || 3000;

// Optimization #4: Pre-warm DNS for common affiliate domains
const COMMON_AFFILIATE_DOMAINS = [
  'pepperjamnetwork.com', 'cj.com', 'shareasale.com', 'awin1.com',
  'gotrackier.com', 'tradedoubler.com', 'adform.net', 'impact.com'
];
// NOTE: These are ONLY used for non-proxy HTTPS calls (like health checks)
// For proxy-based requests, we create fresh agents per request to ensure IP rotation
const httpsAgent = new https.Agent({
  rejectUnauthorized: false,
  keepAlive: false,  // Disable for fresh connections
  timeout: 60000,
});

const httpAgent = new http.Agent({
  keepAlive: false,  // Disable for fresh connections
  timeout: 60000,
});

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);
let proxySettings = null;

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' }),
    new winston.transports.Console({ format: winston.format.simple() })
  ],
});

app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Trackier Dual-URL Webhook Integration (Isolated Module - Safe to disable)
const trackierRoutes = require('./routes/trackier-webhook');
const trackierTraceRoutes = require('./routes/trackier-trace');
const trackierPollingRoutes = require('./routes/trackier-polling');
app.use('/api', trackierRoutes);
app.use('/api', trackierTraceRoutes);
app.use('/api', trackierPollingRoutes);

// Utility function to convert bytes to human-readable format
function formatBytes(bytes) {
  if (bytes === null || bytes === undefined) return 'unknown';
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(Math.max(1, bytes)) / Math.log(k));
  return (bytes / Math.pow(k, i)).toFixed(2) + ' ' + sizes[i];
}

function generateSessionId(length = 16) {
  return crypto.randomBytes(Math.ceil(length / 2)).toString('hex').slice(0, length);
}

function buildProxyUsername(baseUsername, selectedCountry, existingHasRegion = false) {
  let username = baseUsername;

  if (selectedCountry && !existingHasRegion && !username.includes('-region-')) {
    username = `${username}-region-${selectedCountry.toLowerCase()}`;
  }

  const sessId = generateSessionId();
  username = `${username}-sessid-${sessId}-sesstime-90`;
  return username;
}

class UserAgentRotator {
  constructor(options = {}) {
    this.mode = options.mode || process.env.USER_AGENT_MODE || 'dynamic';
    this.poolSize = parseInt(options.poolSize || process.env.USER_AGENT_POOL_SIZE || '10000');
    this.refreshIntervalHours = parseInt(process.env.USER_AGENT_REFRESH_INTERVAL_HOURS || '12');
    this.refreshInterval = this.refreshIntervalHours * 60 * 60 * 1000;

    this.pool = [];
    this.currentIndex = 0;
    this.lastRefresh = Date.now();
    this.totalGenerated = 0;
    this.uniqueGenerated = new Set();
    this.requestCount = 0;

    this.deviceCategories = [
      { deviceCategory: 'mobile', weight: 60 },
      { deviceCategory: 'desktop', weight: 30 },
      { deviceCategory: 'tablet', weight: 10 }
    ];

    logger.info(`UserAgentRotator initialized in '${this.mode}' mode with pool size: ${this.poolSize}`);
    logger.info(`Dynamic generation: Capable of 10,000+ unique user agents for high-volume tracing`);
    logger.info(`Default device distribution: Mobile 60%, Desktop 30%, Tablet 10%`);

    if (this.mode === 'pool' || this.mode === 'hybrid') {
      this.refreshPool();
    }
  }

  // Allow dynamic override of device distribution
  setDeviceDistribution(distribution) {
    if (distribution && Array.isArray(distribution) && distribution.length > 0) {
      this.deviceCategories = distribution;
      logger.info(`Device distribution updated: ${JSON.stringify(distribution)}`);
    }
  }

  generateRandomCategory() {
    const rand = Math.random() * 100;
    let cumulative = 0;

    for (const cat of this.deviceCategories) {
      cumulative += cat.weight;
      if (rand < cumulative) {
        return cat.deviceCategory;
      }
    }
    return 'desktop';
  }

  generateUserAgent() {
    // Use 100% dynamic generation for maximum variety
    // The user-agents package generates unique combinations of:
    // - Browser versions (Chrome 120-131, Firefox 120-122, Safari 17-18, Edge 120-131)
    // - OS versions (Windows 10/11, macOS 14.x, iOS 17.x, Android 13-14)
    // - Device models (1000+ combinations)
    // This provides 10,000+ unique combinations suitable for 100k+ daily traces
    const category = this.generateRandomCategory();
    const userAgent = new UserAgent({ deviceCategory: category });
    const uaString = userAgent.toString();

    this.totalGenerated++;
    this.uniqueGenerated.add(uaString);

    return uaString;
  }

  refreshPool() {
    logger.info(`Refreshing user agent pool with ${this.poolSize} agents...`);
    const startTime = Date.now();

    this.pool = [];
    const uniqueSet = new Set();

    while (uniqueSet.size < this.poolSize) {
      const ua = this.generateUserAgent();
      if (!uniqueSet.has(ua)) {
        uniqueSet.add(ua);
        this.pool.push(ua);
      }

      if (uniqueSet.size % 1000 === 0) {
        logger.info(`Generated ${uniqueSet.size}/${this.poolSize} unique user agents...`);
      }
    }

    this.currentIndex = 0;
    this.lastRefresh = Date.now();

    const duration = Date.now() - startTime;
    logger.info(`User agent pool refreshed with ${this.pool.length} unique agents in ${duration}ms`);
  }

  getNext() {
    this.requestCount++;

    if (this.mode === 'dynamic') {
      return this.generateUserAgent();
    }

    if (this.mode === 'pool' || this.mode === 'hybrid') {
      if (Date.now() - this.lastRefresh > this.refreshInterval) {
        this.refreshPool();
      }

      if (this.pool.length === 0) {
        if (this.mode === 'hybrid') {
          return this.generateUserAgent();
        }
        this.refreshPool();
      }

      const ua = this.pool[this.currentIndex];
      this.currentIndex = (this.currentIndex + 1) % this.pool.length;
      return ua;
    }

    return this.generateUserAgent();
  }

  getRandom() {
    this.requestCount++;

    if (this.mode === 'dynamic') {
      return this.generateUserAgent();
    }

    if (this.mode === 'pool' || this.mode === 'hybrid') {
      if (Date.now() - this.lastRefresh > this.refreshInterval) {
        this.refreshPool();
      }

      if (this.pool.length === 0) {
        if (this.mode === 'hybrid') {
          return this.generateUserAgent();
        }
        this.refreshPool();
      }

      const randomIndex = Math.floor(Math.random() * this.pool.length);
      return this.pool[randomIndex];
    }

    return this.generateUserAgent();
  }

  getStats() {
    const stats = {
      mode: this.mode,
      poolSize: this.mode === 'dynamic' ? 'N/A (generates on-demand)' : this.pool.length,
      configuredPoolSize: this.poolSize,
      currentIndex: this.mode === 'dynamic' ? 'N/A' : this.currentIndex,
      lastRefresh: new Date(this.lastRefresh).toISOString(),
      nextRefresh: this.mode === 'dynamic' ? 'N/A' : new Date(this.lastRefresh + this.refreshInterval).toISOString(),
      refreshIntervalHours: this.refreshIntervalHours,
      totalRequests: this.requestCount,
      totalGenerated: this.totalGenerated,
      uniqueGenerated: this.uniqueGenerated.size,
      repetitionRate: this.requestCount > 0
        ? `${((1 - (this.uniqueGenerated.size / this.requestCount)) * 100).toFixed(2)}%`
        : '0%',
      estimatedDailyCapacity: this.mode === 'dynamic'
        ? 'Unlimited (generates fresh each time)'
        : `${this.poolSize} unique per cycle`,
      deviceDistribution: {
        desktop: '60%',
        mobile: '30%',
        tablet: '10%'
      }
    };

    return stats;
  }
}

const userAgentRotator = new UserAgentRotator();
logger.info(`UserAgentRotator initialized in '${userAgentRotator.mode}' mode with pool size: ${userAgentRotator.poolSize}`);

// Global geo rotators cache (key: pool+strategy+weights hash)
const geoRotators = new Map();

// Detect device type from user agent string
function detectDeviceType(userAgent) {
  const ua = userAgent.toLowerCase();
  
  if (/mobile|android|iphone|ipod|windows phone|blackberry|iemobile/.test(ua)) {
    return 'mobile';
  } else if (/ipad|tablet|playbook|silk|android 3|android 4/.test(ua)) {
    return 'tablet';
  }
  return 'desktop';
}

// Unique fingerprint generator per trace - now synced with user agent
function generateBrowserFingerprint(userAgent) {
  const deviceType = detectDeviceType(userAgent);

  // Randomize Accept-Language with various locale combinations
  const languages = [
    'en-US,en;q=0.9',
    'en-GB,en;q=0.8',
    'en-US,en;q=0.8,fr;q=0.6',
    'en-US,en;q=0.7,es;q=0.5',
    'en-US,en;q=0.9,de;q=0.8',
    'en,en-US;q=0.8',
    'en-CA,en;q=0.9',
    'en-IE,en;q=0.8',
  ];
  const language = languages[Math.floor(Math.random() * languages.length)];

  // Randomize Accept-Encoding
  const encodings = [
    'gzip, deflate, br',
    'gzip, deflate',
    'br, gzip, deflate',
    'gzip, deflate, br, zstd',
  ];
  const encoding = encodings[Math.floor(Math.random() * encodings.length)];

  // Random timezone offset simulation
  const timezones = [
    'UTC', 'GMT', 'GMT+0', 'GMT-1', 'GMT-2', 'GMT-3', 'GMT-4', 'GMT-5',
    'GMT-6', 'GMT-7', 'GMT-8', 'GMT-9', 'GMT-10', 'GMT-11', 'GMT-12',
  ];
  const timezone = timezones[Math.floor(Math.random() * timezones.length)];

  // Device-specific screen resolutions
  let baseResolutions;
  let pixelRatios;
  
  if (deviceType === 'mobile') {
    // Mobile resolutions
    baseResolutions = [
      { width: 375, height: 667 },   // iPhone 6/7/8
      { width: 414, height: 896 },   // iPhone 11/XR
      { width: 390, height: 844 },   // iPhone 12/13
      { width: 393, height: 851 },   // Pixel 6
      { width: 412, height: 915 },   // Android
    ];
    // Mobile typically has higher pixel ratio
    pixelRatios = [2, 2.5, 3];
  } else if (deviceType === 'tablet') {
    // Tablet resolutions
    baseResolutions = [
      { width: 768, height: 1024 },  // iPad
      { width: 810, height: 1080 },  // iPad Air
      { width: 834, height: 1194 },  // iPad Pro 11"
      { width: 1024, height: 1366 }, // iPad Pro 12.9"
    ];
    pixelRatios = [1.5, 2];
  } else {
    // Desktop resolutions
    baseResolutions = [
      { width: 1920, height: 1080 },
      { width: 1366, height: 768 },
      { width: 1440, height: 900 },
      { width: 1536, height: 864 },
      { width: 1280, height: 720 },
      { width: 1920, height: 1200 },
    ];
    // Desktop typically has lower pixel ratio
    pixelRatios = [1, 1.25, 1.5];
  }

  const baseRes = baseResolutions[Math.floor(Math.random() * baseResolutions.length)];
  const viewport = {
    width: baseRes.width + Math.floor(Math.random() * 20 - 10),
    height: baseRes.height + Math.floor(Math.random() * 20 - 10),
  };

  // Color depth variation
  const colorDepths = [24, 32];
  const colorDepth = colorDepths[Math.floor(Math.random() * colorDepths.length)];

  // Pixel ratio (device-specific)
  const pixelRatio = pixelRatios[Math.floor(Math.random() * pixelRatios.length)];

  return {
    language,
    encoding,
    timezone,
    viewport,
    colorDepth,
    pixelRatio,
    deviceType,
  };
}

// Minimal blocking list - only block heavy trackers that may interfere
// Keeping it minimal to avoid detection and allow normal page behavior
const BLOCKED_DOMAINS = [
  'google-analytics.com',
  'googletagmanager.com',
  'doubleclick.net',
  'facebook.com/tr',
];

// Unified resource types to block in browser-based modes to reduce bandwidth
const BLOCKED_RESOURCE_TYPES = [
  'image',
  'stylesheet',
  'font',
  'media',
  'imageset',
  'texttrack',
  'websocket',
  'manifest',
  'other',
];

let browser = null;

async function loadProxySettings() {
  try {
    const { data, error } = await supabase
      .from('settings')
      .select('luna_proxy_host, luna_proxy_port, luna_proxy_username, luna_proxy_password')
      .maybeSingle();

    if (error) throw error;

    if (!data) {
      throw new Error('No proxy settings found in database. Please configure Luna proxy credentials in settings table.');
    }

    if (!data.luna_proxy_host || !data.luna_proxy_port || !data.luna_proxy_username || !data.luna_proxy_password) {
      throw new Error('Incomplete proxy settings in database. Missing: ' +
        [
          !data.luna_proxy_host && 'luna_proxy_host',
          !data.luna_proxy_port && 'luna_proxy_port',
          !data.luna_proxy_username && 'luna_proxy_username',
          !data.luna_proxy_password && 'luna_proxy_password'
        ].filter(Boolean).join(', '));
    }

    proxySettings = {
      host: data.luna_proxy_host,
      port: data.luna_proxy_port,
      username: data.luna_proxy_username,
      password: data.luna_proxy_password,
    };

    logger.info('Proxy settings loaded from database:', {
      host: proxySettings.host,
      port: proxySettings.port,
    });

    return proxySettings;
  } catch (error) {
    logger.error('Failed to load proxy settings from database:', error);
    throw error;
  }
}

async function loadBrightDataApiKey(userId, offerId = null) {
  try {
    // If offer_id is supplied, check for provider override
    if (offerId && userId) {
      const { data: offer, error: offerErr } = await supabase
        .from('offers')
        .select('provider_id')
        .eq('id', offerId)
        .eq('user_id', userId)
        .maybeSingle();

      if (!offerErr && offer && offer.provider_id) {
        const { data: provider, error: provErr } = await supabase
          .from('proxy_providers')
          .select('api_key, provider_type, enabled')
          .eq('id', offer.provider_id)
          .eq('user_id', userId)
          .eq('enabled', true)
          .maybeSingle();

        if (!provErr && provider && provider.provider_type === 'brightdata_browser') {
          if (provider.api_key) {
            logger.info('✅ Loaded Bright Data API key from offer provider override');
            return provider.api_key;
          }
        }
      }
    }

    // Otherwise pick first enabled brightdata_browser provider for the user
    if (userId) {
      const { data: provider, error } = await supabase
        .from('proxy_providers')
        .select('api_key')
        .eq('user_id', userId)
        .eq('provider_type', 'brightdata_browser')
        .eq('enabled', true)
        .limit(1)
        .maybeSingle();

      if (!error && provider && provider.api_key) {
        logger.info('✅ Loaded Bright Data API key from user provider');
        return provider.api_key;
      }
    }

    throw new Error('No enabled Bright Data Browser provider found');
  } catch (error) {
    logger.error('Failed to load Bright Data API key:', error);
    throw error;
  }
}

async function initBrowser(forceNew = false) {
  // If forceNew=true (for traces), always launch fresh browser to get new IP
  // If forceNew=false (for health checks), reuse existing browser
  if (!forceNew && browser) return browser;

  if (!proxySettings) {
    await loadProxySettings();
  }

  const host = proxySettings.host;
  const port = proxySettings.port;

  // CRITICAL: Chrome/Chromium doesn't support auth in --proxy-server URL
  // We'll use page.authenticate() instead after browser launches
  const proxyServer = `http://${host}:${port}`;

  logger.info(forceNew ? 'Launching fresh browser for new IP' : 'Initializing browser with proxy:', proxyServer);

  // macOS workaround: Try to use system Chrome if bundled Chromium fails
  const launchOptions = {
    headless: 'new',
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-accelerated-2d-canvas',
      '--disable-gpu',
      '--window-size=1920x1080',
      `--proxy-server=${proxyServer}`,
      '--disable-extensions',
      '--disable-default-apps',
      '--disable-sync',
      '--disable-translate',
      '--disable-background-networking',
      '--disable-background-timer-throttling',
      '--disable-backgrounding-occluded-windows',
      '--disable-renderer-backgrounding',
      '--disable-client-side-phishing-detection',
      '--disable-hang-monitor',
      '--disable-prompt-on-repost',
      '--disable-domain-reliability',
      '--disable-component-extensions-with-background-pages',
      '--disable-ipc-flooding-protection',
      '--metrics-recording-only',
      '--mute-audio',
      '--no-default-browser-check',
      '--no-first-run',
      '--disable-features=site-per-process,TranslateUI,BlinkGenPropertyTrees',
      '--disable-blink-features=AutomationControlled',
    ],
  };

  // On macOS, try to use system Chrome to avoid ARM/Rosetta issues
  if (process.platform === 'darwin') {
    const chromePaths = [
      '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      '/Applications/Chromium.app/Contents/MacOS/Chromium',
      '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser',
    ];
    
    const fs = require('fs');
    for (const chromePath of chromePaths) {
      if (fs.existsSync(chromePath)) {
        launchOptions.executablePath = chromePath;
        logger.info(`Using system browser: ${chromePath}`);
        break;
      }
    }
  }

  const newBrowser = await puppeteer.launch(launchOptions);

  // CRITICAL: Only update global browser variable if NOT creating a fresh trace browser
  // This prevents orphaning the shared browser instance when forceNew=true
  if (!forceNew) {
    browser = newBrowser;
  }

  return newBrowser;
}

async function fetchGeolocation(username = null, password = null) {
  try {
    if (!proxySettings) {
      await loadProxySettings();
    }

    const response = await axios.get('http://ip-api.com/json/', {
      proxy: {
        host: proxySettings.host,
        port: parseInt(proxySettings.port),
        auth: {
          username: username || proxySettings.username,
          password: password || proxySettings.password,
        },
      },
      timeout: 3000,
    });

    const data = response.data;
    return {
      ip: data.query || 'unknown',
      country: data.country || data.countryCode,
      city: data.city,
      region: data.regionName || data.region,
      full_data: data,
    };
  } catch (error) {
    logger.warn('Geolocation fetch error (non-critical):', error.message);
    return {
      ip: 'unknown',
      country: null,
      city: null,
      region: null,
      error: error.message,
    };
  }
}

async function traceRedirectsHttpOnly(url, options = {}) {
  const {
    maxRedirects = 20,
    timeout = 5000,
    userAgent = userAgentRotator.getNext(),
    targetCountry = null,
    referrer = null,
    referrerHops = null,
    proxyIp = null,
    proxyPort = null,
    expectedFinalUrl = null,
    suffixStep = null,
    debug = false, // Only calculate bandwidth when debug=true
  } = options;

  // Lightweight HTML sniff patterns to mimic browser-like meta/JS redirects without full rendering
  const metaRefreshRegex = /<meta[^>]+http-equiv=["']refresh["'][^>]*content=["'][^"'>]*url=([^"'>\s]+)/i;
  const jsRedirectRegex = /(window\.location|location\.href|location\.replace)\s*=\s*["']([^"']+)["']/i;
  const setTimeoutRedirectRegex = /setTimeout\s*\(\s*function\s*\(\)\s*{[^}]{0,200}?(?:window\.location|location\.href|location\.replace)\s*=\s*["']([^"']+)["']/i;

  logger.info(`⚡ HTTP-only INSTANT (GET + stream headers): ${url.substring(0, 80)}... | maxRedirects: ${maxRedirects}`);
  logger.info(`📱 User-Agent: ${userAgent.substring(0, 80)}...`);

  // Generate unique fingerprint per trace - synced with user agent device type
  const fingerprint = generateBrowserFingerprint(userAgent);
  logger.info(`🖥️ Unique fingerprint: ${fingerprint.deviceType} | viewport=${fingerprint.viewport.width}x${fingerprint.viewport.height}, colorDepth=${fingerprint.colorDepth}, pixelRatio=${fingerprint.pixelRatio}`);

  // Extract and normalize expected final hostname for early stopping
  let expectedFinalHostname = null;
  if (expectedFinalUrl) {
    try {
      const urlObj = new URL(expectedFinalUrl);
      expectedFinalHostname = urlObj.hostname.replace(/^www\./, '');
    } catch (e) {
      // If it's already just a hostname
      expectedFinalHostname = expectedFinalUrl.replace(/^(https?:\/\/)?(www\.)?/, '').split('/')[0];
    }
    if (expectedFinalHostname) {
      logger.info(`🎯 HTTP-only: Will stop at hostname match: ${expectedFinalHostname}`);
    }
  }

  const chain = [];
  let currentUrl = url;
  let redirectCount = 0;
  const visitedUrls = new Set();
  const startBudget = Date.now();
  const budgetMs = timeout;

  if (!proxySettings) {
    await loadProxySettings();
  }

  const proxyPassword = proxySettings.password;
  const proxyHost = proxySettings.host;
  const proxyPortNum = parseInt(proxyPort || proxySettings.port);

  const proxyUsername = buildProxyUsername(
    proxyIp || proxySettings.username,
    targetCountry || null,
    !!proxyIp
  );

  if (!proxyIp && targetCountry && targetCountry.length === 2) {
    logger.info(`🌍 HTTP-only: Geo-targeting ${targetCountry.toUpperCase()}`);
  } else {
    logger.info(`🔄 HTTP-only: Using Luna proxy (new connection = new IP)`);
  }

  const proxyUrl = `http://${proxyUsername}:${proxyPassword}@${proxyHost}:${proxyPortNum}`;
  
  // Optimization #2: Reuse connections WITHIN this trace (but fresh agent per trace = new IP)
  // Luna rotates IPs on new agent creation, but we can reuse within single trace
  const traceAgent = new HttpsProxyAgent(proxyUrl, {
    keepAlive: true,   // Reuse within this trace for speed
    maxSockets: 5,     // Allow concurrent hops
    timeout: 15000,
  });

  // Track hop timings for adaptive timeout allocation (EMA)
  const hopTimings = [];

  // HTTP-only mode: HEADERS ONLY - no body download at all
  const MAX_BODY_BYTES = 0; // Headers only, no body
  const MAX_TOTAL_BANDWIDTH = 2048; // ~2 KB cap for entire trace
  let totalBandwidthUsed = 0; // Track cumulative bandwidth across all hops
  
  // Wait for got module
  while (!gotModule) await new Promise(r => setTimeout(r, 10));
  const got = gotModule;

  // TRUE PARALLEL STREAMING STRATEGY:
  // Launch all hops in parallel, racing to get headers
  // As soon as we get a Location header, fire the next hop WITHOUT waiting
  // Final URL = first hop with no Location header or non-3xx status
  
  let hopIndex = 0;
  const allResults = [];
  let finalHopResolved = false;
  let hopCount = 0;
  let concurrentHops = 0;
  let maxConcurrentHops = 0;
  
  const launchHop = (url) => {
    hopCount++;
    concurrentHops++;
    if (concurrentHops > maxConcurrentHops) {
      maxConcurrentHops = concurrentHops;
    }
    
    const currentHopIndex = hopIndex++;
    const hopStart = Date.now();
    
    const remainingBudget = budgetMs - (Date.now() - startBudget);
    
    // Check if overall bandwidth cap reached
    if (totalBandwidthUsed >= MAX_TOTAL_BANDWIDTH) {
      logger.info(`  🛑 Hop ${currentHopIndex + 1}: overall bandwidth cap (${formatBytes(MAX_TOTAL_BANDWIDTH)}) reached`);
      const result = {
        url,
        status: 0,
        redirect_type: 'error',
        method: 'bandwidth_cap',
        error: 'Total bandwidth cap reached',
        timing_ms: 0,
        bandwidth_bytes: 0,
        hopIndex: currentHopIndex,
      };
      allResults.push(result);
      finalHopResolved = true;
      concurrentHops--;
      return;
    }
    
    if (remainingBudget <= 0) {
      const result = {
        url,
        status: 0,
        redirect_type: 'error',
        method: 'timeout',
        error: 'Budget exceeded',
        timing_ms: 0,
        bandwidth_bytes: 0,
        hopIndex: currentHopIndex,
      };
      allResults.push(result);
      concurrentHops--;
      return;
    }
    
    // Optimization #1: Adaptive timeout - start lower, adjust based on actual performance
    const avgHopTime = hopTimings.length > 0 
      ? hopTimings.slice(-3).reduce((a, b) => a + b, 0) / Math.min(3, hopTimings.length)
      : 3000; // Start at 3s, will adapt up if needed
    
    // Some affiliate domains (e.g., awin/doubleclick/elcorteingles) are consistently slower; raise the floor to avoid premature timeouts.
    const slowAffiliatePatterns = [/awin1\.com/i, /doubleclick\.net/i, /elcorteingles\.es/i, /gomobupps\.com/i, /c3me6x\.net/i];
    const timeoutFloor = slowAffiliatePatterns.some((p) => p.test(url)) ? 8000 : 5000;

    const budgetPerHop = Math.max(timeoutFloor, Math.min(remainingBudget * 0.7, avgHopTime * 1.2));
    
    logger.info(`  🚀 Hop ${currentHopIndex + 1} (parallel, concurrent=${concurrentHops}): ${url.substring(0, 60)}...`);
    
    // Use AbortController for instant cancellation
    const abortController = new AbortController();
    const timeoutId = setTimeout(() => abortController.abort(), budgetPerHop);
    
    try {
      // Determine if referrer should be applied to this hop
      const currentHopNumber = currentHopIndex + 1; // 1-indexed
      const shouldApplyReferrer = referrer && (
        !referrerHops || 
        referrerHops.length === 0 || 
        referrerHops.includes(currentHopNumber)
      );
      
      // Use got.stream() with AbortController for instant kill
      const stream = got.stream(url, {
        signal: abortController.signal,
        agent: { https: traceAgent, http: traceAgent },
        followRedirect: false,
        decompress: false,
        throwHttpErrors: false,
        headers: {
          'user-agent': userAgent,
          'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'accept-language': fingerprint.language,
          'accept-encoding': fingerprint.encoding,
          'connection': 'close', // Don't keep alive - we're killing it anyway
          ...(shouldApplyReferrer ? { 'referer': referrer } : {}),
        },
        retry: { limit: 0 },
        timeout: {
          connect: Math.max(6000, timeoutFloor + 1000),  // give slow domains more time to establish
          response: Math.max(3000, Math.floor(timeoutFloor * 0.75)), // and more time to respond
        },
        method: 'GET',
      });
      
      // Track actual bandwidth: headers only (no body download)
      let actualBandwidth = 0;
      let responseReceived = false;
      
      // Abort immediately on any body data AFTER we get response headers
      stream.on('data', (chunk) => {
        if (responseReceived) {
          // Kill stream immediately after headers - we don't want body data
          abortController.abort();
        }
      });
      
      // INSTANT ACTION: As soon as headers arrive, process and kill stream!
      stream.on('response', (response) => {
        responseReceived = true;
        const timing = Date.now() - hopStart;
        hopTimings.push(timing);
        
        const status = response.statusCode || 0;
        const headers = response.headers || {};
        const location = headers['location'];
        
        // CRITICAL: If this is a final URL (200 status), kill immediately to save bandwidth
        const isFinalUrl = status >= 200 && status < 300;
        
        // Check if we've reached the expected final URL hostname (early stop optimization)
        let reachedExpectedFinal = false;
        if (expectedFinalHostname && isFinalUrl) {
          try {
            const currentHostname = new URL(url).hostname.replace(/^www\./, '');
            reachedExpectedFinal = (currentHostname === expectedFinalHostname);
            if (reachedExpectedFinal) {
              logger.info(`  🪶 HTTP-only: Expected final URL reached - stopping early`);
            }
          } catch (e) {}
        }
        
        // Track minimal bandwidth - only count Location header for redirects, null for final
        // Skip calculation entirely when debug=false to save CPU
        if (debug) {
          if (isFinalUrl) {
            // Final URL: no bandwidth counted (minimal mode like browser)
            actualBandwidth = null;
          } else if (location) {
            // Redirect: only count status line + Location header (~200-400 bytes)
            actualBandwidth = location.length + 100; // Location header + status line overhead
            totalBandwidthUsed += actualBandwidth;
          } else {
            // No location but not 200: minimal overhead
            actualBandwidth = 100;
            totalBandwidthUsed += actualBandwidth;
          }
          const bandwidthDisplay = actualBandwidth === null ? 'minimal' : formatBytes(actualBandwidth);
          logger.info(`  ✅ Hop ${currentHopIndex + 1} (${status}) in ${timing}ms, ~${bandwidthDisplay} ${isFinalUrl ? '🛑 FINAL' : ''} [parallel, concurrent=${concurrentHops}]`);
        } else {
          actualBandwidth = null; // Skip bandwidth calculation when debug=false
          logger.info(`  ✅ Hop ${currentHopIndex + 1} (${status}) in ${timing}ms ${isFinalUrl ? '🛑 FINAL' : ''} [parallel, concurrent=${concurrentHops}]`);
        }
        
        const result = {
          url,
          status,
          redirect_type: status >= 300 && status < 400 ? 'http' : status >= 200 && status < 300 ? 'final' : 'error',
          method: 'parallel_stream',
          timing_ms: timing,
          bandwidth_bytes: actualBandwidth,
          hopIndex: currentHopIndex,
        };
        
        // Extract params from final URL
        if (status >= 200 && status < 300) {
          const params = {};
          try {
            const urlObj = new URL(url);
            urlObj.searchParams.forEach((value, key) => {
              params[key] = value;
            });
            result.params = params;
          } catch (e) {}
        }
        
        // If 3xx with Location, launch next hop IMMEDIATELY (don't await!)
        if (status >= 300 && status < 400 && location) {
          try {
            const nextUrl = new URL(location, url).toString();
            
            if (!visitedUrls.has(nextUrl) && redirectCount < maxRedirects - 1) {
              visitedUrls.add(nextUrl);
              redirectCount++;
              
              allResults.push(result);
              
              // KILL EVERYTHING INSTANTLY - do this AFTER pushing result
              clearTimeout(timeoutId);
              stream.destroy(); // Destroy the stream
              try { response.destroy(); } catch (e) {} // Destroy the response
              
              // FIRE AND FORGET - launch next hop in background without waiting!
              launchHop(nextUrl);
              concurrentHops--;
              return;
            } else if (visitedUrls.has(nextUrl)) {
              result.error = 'Loop detected';
              result.redirect_type = 'error';
              finalHopResolved = true;
            }
          } catch (e) {
            result.error = `Invalid URL: ${location}`;
            result.redirect_type = 'error';
            finalHopResolved = true;
          }
        } else if (status >= 200 && status < 300) {
          // FINAL URL - stop immediately, blocking body download
          result.redirect_type = 'final';
          finalHopResolved = true;

          // Extract params from final URL
          const params = {};
          try {
            const urlObj = new URL(url);
            urlObj.searchParams.forEach((value, key) => {
              params[key] = value;
            });
            result.params = params;
          } catch (e) {}

          allResults.push(result);

          // KILL CONNECTION IMMEDIATELY - don't wait for body
          clearTimeout(timeoutId);
          stream.destroy();
          try { response.destroy(); } catch (e) {}

          logger.info(`  🎯 Final URL reached at hop ${currentHopIndex + 1} - connection killed to save bandwidth`);
          concurrentHops--;
          return;
        } else {
          // Error status - trace ends here
          logger.info(`  ⚠️ Error status ${status} at hop ${currentHopIndex + 1}`);
          finalHopResolved = true;
        }
        
        allResults.push(result);
        
        // KILL STREAMS after processing
        clearTimeout(timeoutId);
        stream.destroy();
        try { response.destroy(); } catch (e) {}
        concurrentHops--;
      });
      
      stream.on('error', (err) => {
        clearTimeout(timeoutId);
        
        const timing = Date.now() - hopStart;
        hopTimings.push(timing);
        
        // Check if this is a timeout abort (intentional)
        if (err.name === 'AbortError' || err.code === 'ERR_ABORTED') {
          logger.info(`  ⏱️ Hop ${currentHopIndex + 1} timeout after ${timing}ms`);
          
          const result = {
            url,
            status: 0,
            redirect_type: 'error',
            method: 'parallel_stream',
            error: 'Request timeout',
            timing_ms: timing,
            bandwidth_bytes: 0,
            hopIndex: currentHopIndex,
          };
          
          allResults.push(result);
          finalHopResolved = true;
          concurrentHops--;
          return;
        }
        
        // Other errors
        logger.info(`  ❌ Hop ${currentHopIndex + 1} error: ${err.code || err.message}`);
        
        const result = {
          url,
          status: 0,
          redirect_type: 'error',
          method: 'parallel_stream',
          error: err.code || err.message,
          timing_ms: timing,
          bandwidth_bytes: 0,
          hopIndex: currentHopIndex,
        };
        
        allResults.push(result);
        finalHopResolved = true;
        concurrentHops--;
      });
      
    } catch (err) {
      clearTimeout(timeoutId);
      
      const timing = Date.now() - hopStart;
      hopTimings.push(timing);
      
      logger.info(`  ❌ Hop ${currentHopIndex + 1} error: ${err.code || err.message}`);
      
      const result = {
        url,
        status: 0,
        redirect_type: 'error',
        method: 'parallel_stream',
        error: err.code || err.message,
        timing_ms: timing,
        bandwidth_bytes: 0,
        hopIndex: currentHopIndex,
      };
      
      allResults.push(result);
      finalHopResolved = true;
      concurrentHops--;
    }
  };
  
  // Launch first hop (non-blocking)
  visitedUrls.add(currentUrl);
  launchHop(currentUrl);
  
  // Wait for final hop to be reached or all hops complete
  // Use event-driven completion instead of polling to reduce CPU usage
  const maxWaitMs = budgetMs * 3; // Allow 3x the per-hop timeout for full chain
  await new Promise(resolve => {
    // Check if already complete
    if (finalHopResolved || concurrentHops === 0) {
      resolve();
      return;
    }
    
    // Set up completion checker that will be called by hop handlers
    const completionChecker = setInterval(() => {
      if (finalHopResolved || concurrentHops === 0) {
        clearInterval(completionChecker);
        resolve();
      }
    }, 300); // Check every 300ms (still 3x less frequent than before)
    
    // Timeout fallback
    setTimeout(() => {
      clearInterval(completionChecker);
      resolve();
    }, maxWaitMs);
  });
  
  // Sort by hop index to maintain order
  allResults.sort((a, b) => a.hopIndex - b.hopIndex);
  
  // Build chain from results
  for (const result of allResults) {
    const { hopIndex, ...chainEntry } = result;
    chain.push(chainEntry);
  }

  if (redirectCount >= maxRedirects) {
    chain.push({
      url: 'max_redirects_reached',
      status: 0,
      redirect_type: 'error',
      method: 'limit',
      error: `Max ${maxRedirects} redirects`,
    });
  }

  const totalBandwidth = debug ? chain.reduce((sum, e) => sum + (e.bandwidth_bytes || 0), 0) : 0;
  const avgBandwidth = debug && chain.length > 0 ? totalBandwidth / chain.length : 0;

  if (debug) {
    logger.info(`✅ HTTP-only trace complete: ${chain.length} steps (${hopCount} hops launched, max concurrent=${maxConcurrentHops}), ${formatBytes(totalBandwidth)}`);
  } else {
    logger.info(`✅ HTTP-only trace complete: ${chain.length} steps (${hopCount} hops launched, max concurrent=${maxConcurrentHops})`);
  }

  // Extract params from location header of last redirect (for special scenarios)
  let locationUrl = null;
  let locationParams = {};
  if (chain.length > 0) {
    // Find the last redirect entry (not final page)
    const lastRedirect = [...chain].reverse().find(entry => 
      entry.status >= 300 && entry.status < 400
    );
    
    // Note: http_only mode doesn't store headers in chain, only tracks redirects
    // Location URL is already followed and stored as next entry's URL
    // This mode prioritizes speed over detailed header extraction
  }

  return {
    success: chain.length > 0 && chain[chain.length - 1].redirect_type !== 'error',
    chain,
    total_steps: chain.length,
    final_url: chain.length > 0 ? chain[chain.length - 1].url : url,
    user_agent: userAgent,
    total_bandwidth_bytes: totalBandwidth,
    bandwidth_per_step_bytes: Math.round(avgBandwidth),
    parallel_metrics: {
      total_hops_launched: hopCount,
      max_concurrent_hops: maxConcurrentHops,
      execution_model: 'true_parallel_streaming',
    },
  };
}

// Bright Data Browser API tracer - follows all patterns (geo, UA rotation, fingerprint matching, bandwidth optimization)
async function traceRedirectsBrightDataBrowser(url, options = {}) {
  const {
    maxRedirects = 20,
    timeout = 90000,
    userAgent = userAgentRotator.getNext(),
    targetCountry = null,
    referrer = null,
    referrerHops = null,
    apiKey = null,
    userContext = null,
  } = options;

  if (!apiKey) {
    throw new Error('Bright Data Browser API key is required');
  }

  const chain = [];
  let currentUrl = url;
  const seen = new Set();
  const API_URL = 'https://api.brightdata.com/request';
  
  // Generate unique fingerprint per trace - synced with user agent device type
  const fingerprint = generateBrowserFingerprint(userAgent);
  logger.info(`🌐 Bright Data Browser: Device=${fingerprint.deviceType}, viewport=${fingerprint.viewport.width}x${fingerprint.viewport.height}`);
  logger.info(`🎭 Using User Agent: ${userAgent.substring(0, 80)}...`);
  
  if (targetCountry) {
    logger.info(`🌍 Bright Data Browser: Geo-targeting ${targetCountry.toUpperCase()}`);
  }

  const buildPayload = (targetUrl, hopNumber = 1) => {
    const payload = {
      zone: 'scraping_browser1',
      url: targetUrl,
      format: 'raw',
    };

    if (targetCountry && targetCountry.length === 2) {
      payload.country = targetCountry.toLowerCase();
    }

    // CRITICAL: Add user_context to fix "user context" error
    if (userContext && userContext.user_id) {
      payload.user_context = {
        user_id: userContext.user_id,
        account_id: userContext.account_id || userContext.user_id,
        session_id: userContext.session_id || `session-${Date.now()}`,
        provider_id: userContext.provider_id,
      };
      logger.info(`🔐 Bright Data user context set: ${userContext.user_id}`);
    }

    // Apply fingerprint-matched headers
    payload.headers = {
      'Accept-Language': fingerprint.language,
      'Accept-Encoding': fingerprint.encoding,
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    };

    if (userAgent) {
      payload.headers['User-Agent'] = userAgent;
    }

    // Apply referrer based on hop configuration
    const shouldApplyReferrer = referrer && (
      !referrerHops || 
      referrerHops.length === 0 || 
      referrerHops.includes(hopNumber)
    );
    
    if (shouldApplyReferrer) {
      payload.headers['Referer'] = referrer;
    }

    return payload;
  };

  const parseMetaRefresh = (html) => {
    const match = html.match(/<meta[^>]+http-equiv=["']refresh["'][^>]+content=["'][^"']*url=([^"']+)["']/i);
    if (match && match[1]) {
      return match[1].trim().replace(/^['"]|['"]$/g, '');
    }
    return null;
  };

  const parseJsRedirect = (html) => {
    const patterns = [
      /location\s*\.\s*(?:href|replace)\s*=\s*["']([^"']+)["']/i,
      /window\s*\.\s*location\s*=\s*["']([^"']+)["']/i,
    ];

    for (const pattern of patterns) {
      const match = html.match(pattern);
      if (match && match[1]) {
        return match[1].trim();
      }
    }
    return null;
  };

  const parseParamRedirect = (currentUrl) => {
    try {
      const urlObj = new URL(currentUrl);
      const keys = ['deeplink', 'd', 'url', 'u', 'redir', 'redirect', 'target', 'dest', 'destination', 'next', 'return', 'r'];
      
      for (const key of keys) {
        const val = urlObj.searchParams.get(key);
        if (val) {
          try {
            const decoded = decodeURIComponent(val);
            if (decoded.startsWith('http')) return decoded;
          } catch (e) {
            if (val.startsWith('http')) return val;
          }
        }
      }
    } catch (_err) {
      return null;
    }
    return null;
  };

  const cleanUrl = (url) => {
    if (!url) return null;
    return url.trim().replace(/^['"]+|['"]+$/g, '');
  };

  try {
    for (let hop = 1; hop <= maxRedirects; hop++) {
      if (seen.has(currentUrl)) {
        logger.info(`⚠️ Bright Data: Detected loop at ${currentUrl}`);
        break;
      }
      seen.add(currentUrl);

      const payload = buildPayload(currentUrl, hop); // Pass hop number
      const startTime = Date.now();

      logger.info(`🔄 Bright Data hop ${hop}: ${currentUrl.substring(0, 100)}...`);

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);

      let response, html, bandwidth = 0;
      
      try {
        response = await fetch(API_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`,
          },
          body: JSON.stringify(payload),
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(`Bright Data API error ${response.status}: ${errorText.substring(0, 200)}`);
        }

        html = await response.text();
        bandwidth = Buffer.byteLength(html, 'utf8');
        
      } catch (err) {
        clearTimeout(timeoutId);
        logger.error(`❌ Bright Data hop ${hop} failed: ${err.message}`);
        
        chain.push({
          url: currentUrl,
          status: 0,
          redirect_type: 'error',
          method: 'GET',
          error: err.message,
          timing_ms: Date.now() - startTime,
          bandwidth_bytes: 0,
        });
        break;
      }

      const timing = Date.now() - startTime;
      
      chain.push({
        url: currentUrl,
        status: 200,
        redirect_type: 'brightdata_browser',
        method: 'GET',
        html_snippet: html.substring(0, 500),
        timing_ms: timing,
        bandwidth_bytes: bandwidth,
      });

      // Extract next URL from headers, meta refresh, JS, or params
      const redirectedTo = response.headers.get('x-unblocker-redirected-to');
      const metaRefresh = parseMetaRefresh(html);
      const jsRedirect = parseJsRedirect(html);
      const paramRedirect = parseParamRedirect(currentUrl);

      let nextUrl = cleanUrl(redirectedTo || metaRefresh || jsRedirect || paramRedirect);

      if (!nextUrl) {
        logger.info(`✅ Bright Data: No further redirects detected at hop ${hop}`);
        break;
      }

      currentUrl = nextUrl;
      logger.info(`➡️ Bright Data: Following to ${nextUrl.substring(0, 100)}...`);
    }

    if (chain.length >= maxRedirects) {
      chain.push({
        url: 'max_redirects_reached',
        status: 0,
        redirect_type: 'error',
        method: 'limit',
        error: `Max ${maxRedirects} redirects`,
      });
    }

    const totalBandwidth = chain.reduce((sum, e) => sum + (e.bandwidth_bytes || 0), 0);
    const avgBandwidth = chain.length > 0 ? totalBandwidth / chain.length : 0;

    logger.info(`✅ Bright Data Browser trace complete: ${chain.length} steps, ${formatBytes(totalBandwidth)}`);

    return {
      success: chain.length > 0 && chain[chain.length - 1].redirect_type !== 'error',
      chain,
      total_steps: chain.length,
      final_url: chain.length > 0 ? chain[chain.length - 1].url : url,
      user_agent: userAgent,
      total_bandwidth_bytes: totalBandwidth,
      bandwidth_per_step_bytes: Math.round(avgBandwidth),
    };

  } catch (error) {
    logger.error(`❌ Bright Data Browser tracer failed: ${error.message}`);
    throw error;
  }
}

async function traceRedirectsBrowser(url, options = {}) {
  const {
    maxRedirects = 20,
    timeout = 60000,
    userAgent = userAgentRotator.getNext(),
    targetCountry = selectedCountry || null,
    referrer = null,
    referrerHops = null, // NEW: Array of hop numbers [1,2,3] or null for all hops
    expectedFinalUrl = null,
    suffixStep = null,
    extractFromLocationHeader = false,
    locationExtractHop = null,
  } = options;

  const chain = [];
  const popupChains = [];
  let traceBrowser = null;
  let page = null;

  try {
    // Launch FRESH browser per trace - each new browser process = potential new IP
    traceBrowser = await initBrowser(true);
    page = await traceBrowser.newPage();

    if (!proxySettings) {
      await loadProxySettings();
    }

    // CRITICAL: Generate UNIQUE random ID per trace to force fresh Luna connection
    // This matches HTTP-only's approach: new agent/credentials = new IP
    const traceSessionId = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    let proxyUsername = buildProxyUsername(proxySettings.username, targetCountry || null);
    const proxyPassword = proxySettings.password;

    // Apply geo-targeting via Luna region parameter
    if (targetCountry && targetCountry.length === 2) {
      const countryCode = targetCountry.toLowerCase();
      logger.info(`🌍 Browser: Geo-targeting ${countryCode.toUpperCase()} (session: ${traceSessionId.substring(0, 8)}...)`);
    } else {
      logger.info(`🔄 Browser: Fresh Luna connection (session: ${traceSessionId.substring(0, 8)}...)`);
    }

    // MUST authenticate before any requests to ensure Luna sees the username
    await page.authenticate({
      username: proxyUsername,
      password: proxyPassword,
    });

    // CRITICAL: Unique session ID per trace = unique username = fresh Luna connection
    // This forces Luna to treat each trace as a new session, rotating IPs

    await page.setUserAgent(userAgent);
    logger.info(`🎭 Using User Agent: ${userAgent.substring(0, 80)}...`);
    
    // Generate unique fingerprint per trace - synced with user agent device type
    const fingerprint = generateBrowserFingerprint(userAgent);
    logger.info(`🖥️ Unique fingerprint: ${fingerprint.deviceType} | viewport=${fingerprint.viewport.width}x${fingerprint.viewport.height}, colorDepth=${fingerprint.colorDepth}, pixelRatio=${fingerprint.pixelRatio}`);
    
    await page.setViewport(fingerprint.viewport);

    // Set realistic browser headers with unique fingerprint
    const headers = {
      'Accept-Language': fingerprint.language,
      'Accept-Encoding': fingerprint.encoding,
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
      'Upgrade-Insecure-Requests': '1',
      'Cache-Control': 'max-age=0',
    };
    
    // DO NOT set Referer in global headers - it will be applied per-hop in the request interceptor
    if (referrer) {
      if (referrerHops && referrerHops.length > 0) {
        logger.info(`🔗 Browser will apply referrer only on hops ${referrerHops.join(',')}: ${referrer}`);
      } else {
        logger.info(`🔗 Browser will apply referrer on ALL hops: ${referrer}`);
      }
    }
    
    await page.setExtraHTTPHeaders(headers);

    // Enhanced stealth: mask automation indicators + randomize fingerprints + advanced redirect detection
    await page.evaluateOnNewDocument(() => {
      // Initialize redirect log
      window.__redirectLog = [];
      window.__formSubmissions = [];
      
      // Override webdriver property
      Object.defineProperty(navigator, 'webdriver', {
        get: () => false,
      });
      
      // Mock plugins
      Object.defineProperty(navigator, 'plugins', {
        get: () => [1, 2, 3, 4, 5],
      });
      
      // Mock languages
      Object.defineProperty(navigator, 'languages', {
        get: () => ['en-US', 'en'],
      });
      
      // Add chrome object
      window.chrome = {
        runtime: {},
      };
      
      // Override permissions
      const originalQuery = window.navigator.permissions.query;
      window.navigator.permissions.query = (parameters) => (
        parameters.name === 'notifications' ?
          Promise.resolve({ state: Notification.permission }) :
          originalQuery(parameters)
      );
      
      // Randomize Canvas fingerprint
      const getRandomValues = window.crypto.getRandomValues.bind(window.crypto);
      Object.defineProperty(window.crypto, 'getRandomValues', {
        value: function(typedArray) {
          getRandomValues(typedArray);
          for (let i = 0; i < typedArray.length; i++) {
            typedArray[i] = (typedArray[i] + Math.floor(Math.random() * 256)) % 256;
          }
          return typedArray;
        },
      });
      
      // Randomize WebGL fingerprint
      const getParameter = WebGLRenderingContext.prototype.getParameter;
      WebGLRenderingContext.prototype.getParameter = function(parameter) {
        if (parameter === 37445) {
          return 'Intel Inc.';
        }
        if (parameter === 37446) {
          return 'Intel Iris OpenGL Engine';
        }
        return getParameter.call(this, parameter);
      };
      
      // ADVANCED REDIRECT DETECTION: Intercept all navigation methods
      const interceptors = {
        locationSetter: Object.getOwnPropertyDescriptor(window.Location.prototype, 'href'),
        locationReplace: window.location.replace,
        locationAssign: window.location.assign,
        historyPushState: window.history.pushState,
        historyReplaceState: window.history.replaceState,
      };

      // Override location.href setter
      Object.defineProperty(window.location, 'href', {
        get: () => interceptors.locationSetter.get.call(window.location),
        set: (url) => {
          window.__redirectLog.push({
            type: 'location.href',
            url: url,
            timestamp: Date.now(),
          });
          return interceptors.locationSetter.set.call(window.location, url);
        }
      });

      // Override location.replace
      window.location.replace = function(url) {
        window.__redirectLog.push({
          type: 'location.replace',
          url: url,
          timestamp: Date.now(),
        });
        return interceptors.locationReplace.call(window.location, url);
      };

      // Override location.assign
      window.location.assign = function(url) {
        window.__redirectLog.push({
          type: 'location.assign',
          url: url,
          timestamp: Date.now(),
        });
        return interceptors.locationAssign.call(window.location, url);
      };

      // Detect setTimeout/setInterval redirects
      const originalSetTimeout = window.setTimeout;
      const originalSetInterval = window.setInterval;

      window.setTimeout = function(fn, delay, ...args) {
        const fnString = fn.toString();
        if (fnString.includes('location') || fnString.includes('redirect') || fnString.includes('href')) {
          window.__redirectLog.push({
            type: 'setTimeout_redirect',
            delay: delay,
            timestamp: Date.now(),
          });
        }
        return originalSetTimeout.call(window, fn, delay, ...args);
      };

      window.setInterval = function(fn, delay, ...args) {
        const fnString = fn.toString();
        if (fnString.includes('location') || fnString.includes('redirect') || fnString.includes('href')) {
          window.__redirectLog.push({
            type: 'setInterval_redirect',
            delay: delay,
            timestamp: Date.now(),
          });
        }
        return originalSetInterval.call(window, fn, delay, ...args);
      };

      // Monitor meta refresh tags
      const metaObserver = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeName === 'META' && node.httpEquiv?.toLowerCase() === 'refresh') {
              const content = node.content || '';
              const urlMatch = /url=([^;\s]+)/i.exec(content);
              if (urlMatch) {
                window.__redirectLog.push({
                  type: 'meta_refresh',
                  url: urlMatch[1],
                  content: content,
                  timestamp: Date.now(),
                });
              }
            }
          });
        });
      });

      // Monitor form submissions
      const formObserver = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeName === 'FORM') {
              const form = node;
              const originalSubmit = form.submit;
              form.submit = function() {
                window.__formSubmissions.push({
                  action: form.action,
                  method: form.method || 'GET',
                  timestamp: Date.now(),
                });
                return originalSubmit.call(form);
              };
            }
          });
        });
      });

      document.addEventListener('DOMContentLoaded', () => {
        if (document.head) {
          metaObserver.observe(document.head, { childList: true, subtree: true });
        }
        if (document.body) {
          formObserver.observe(document.body, { childList: true, subtree: true });
        }
        
        // Monitor existing forms
        document.querySelectorAll('form').forEach((form) => {
          const originalSubmit = form.submit;
          form.submit = function() {
            window.__formSubmissions.push({
              action: form.action,
              method: form.method || 'GET',
              timestamp: Date.now(),
            });
            return originalSubmit.call(form);
          };
        });
      });
      
      // Disable animations for faster loading
      const style = document.createElement('style');
      style.textContent = `
        * {
          animation-duration: 0s !important;
          animation-delay: 0s !important;
          transition-duration: 0s !important;
          transition-delay: 0s !important;
        }
      `;
      document.addEventListener('DOMContentLoaded', () => {
        document.head.appendChild(style);
      });
    });

    await page.setRequestInterception(true);

    const redirectChain = [];
    let requestCount = 0;
    let lastUrlChange = Date.now();
    
    // Track ALL requests to detect retries
    const requestLog = {
      documentRequests: new Map(),
      totalRequests: 0,
      retryAttempts: 0,
      startTime: Date.now(),
    };

    // Enable a minimal, low-bandwidth mode once we hit the expected final URL
    let finalHopMinimalMode = false;
    let pageClosed = false;  // Track if page was explicitly closed
    let finalHopUrl = null;
    const activateFinalHopMinimalMode = (triggerUrl, reason) => {
      if (finalHopMinimalMode) return;
      finalHopMinimalMode = true;
      finalHopUrl = triggerUrl;
      logger.info(`🪶 Browser: Final-hop minimal mode enabled (${reason}) for ${triggerUrl.substring(0, 80)}...`);
      page.setJavaScriptEnabled(false).catch(err => logger.warn(`Final-hop JS disable failed: ${err.message}`));
    };

    page.on('framenavigated', (frame) => {
      if (frame === page.mainFrame()) {
        lastUrlChange = Date.now();
      }
    });

    page.on('request', (request) => {
      const resourceType = request.resourceType();
      const requestUrl = request.url();
      
      requestLog.totalRequests++;

      if (resourceType === 'document') {
        // Check if this document URL matches the expected final destination (by hostname)
        if (expectedFinalUrl) {
          try {
            const urlHostname = new URL(requestUrl).hostname.replace(/^www\./, '');
            const expectedHostname = expectedFinalUrl.replace(/^(https?:\/\/)?(www\.)?/, '').split('/')[0];
            // Only match if both hostnames are non-empty to avoid false matches with about:blank
            if (urlHostname && expectedHostname && 
                (urlHostname === expectedHostname)) {
              activateFinalHopMinimalMode(requestUrl, 'expected_final_url_match');
            }
          } catch (e) {
            // If URL parsing fails, fall back to simple includes check
            if (requestUrl.includes(expectedFinalUrl)) {
              activateFinalHopMinimalMode(requestUrl, 'expected_final_url_match');
            }
          }
        }

        const startTime = Date.now();
        const key = `${request.method()}-${requestUrl}`;
        
        // Check if this document URL was already requested (indicates retry)
        if (requestLog.documentRequests.has(key)) {
          const existing = requestLog.documentRequests.get(key);
          existing.retryCount = (existing.retryCount || 0) + 1;
          requestLog.retryAttempts++;
          logger.warn(`🔄 BROWSER RETRY DETECTED: ${requestUrl} (attempt ${existing.retryCount + 1})`);
        } else {
          requestLog.documentRequests.set(key, {
            url: requestUrl,
            method: request.method(),
            timestamp: Date.now(),
            retryCount: 0,
          });
          logger.info(`📄 Browser document request #${requestLog.documentRequests.size}: ${requestUrl}`);
        }
        
        redirectChain.push({
          url: requestUrl,
          method: request.method(),
          headers: request.headers(),
          startTime,
        });
        requestCount++;
      }

      const isBlockedDomain = BLOCKED_DOMAINS.some(domain => requestUrl.includes(domain));
      const finalHopSubresource = finalHopMinimalMode && resourceType !== 'document';
      const shouldBlock = finalHopSubresource || BLOCKED_RESOURCE_TYPES.includes(resourceType) || (isBlockedDomain && resourceType !== 'document');

      if (shouldBlock) {
        request.abort();
      } else {
        // Apply referrer based on referrerHops configuration
        // If referrerHops is null/empty -> apply to ALL hops (default behavior)
        // If referrerHops is an array -> apply only to specified hop numbers (1-indexed)
        const currentHopNumber = requestLog.documentRequests.size;
        const shouldApplyReferrer = referrer && resourceType === 'document' && (
          !referrerHops || 
          referrerHops.length === 0 || 
          referrerHops.includes(currentHopNumber)
        );
        
        if (resourceType === 'document') {
          const currentHeaders = request.headers();
          const hasReferer = currentHeaders['referer'] || currentHeaders['Referer'];
          logger.info(`🔍 Browser Mode - Hop ${currentHopNumber}: referrer=${referrer}, referrerHops=${JSON.stringify(referrerHops)}, shouldApply=${shouldApplyReferrer}`);
          logger.info(`   📋 Current request headers Referer: ${hasReferer || 'NOT SET'}`);
        }
        
        if (shouldApplyReferrer) {
          const overrideHeaders = {
            ...request.headers(),
            'Referer': referrer,
          };
          logger.info(`   ✅ APPLYING Referer header: ${referrer}`);
          request.continue({ headers: overrideHeaders });
        } else {
          // Explicitly remove Referer header if it exists (browser may add it automatically)
          const currentHeaders = request.headers();
          if (currentHeaders['referer'] || currentHeaders['Referer']) {
            const cleanHeaders = { ...currentHeaders };
            delete cleanHeaders['referer'];
            delete cleanHeaders['Referer'];
            logger.info(`   🗑️ REMOVING existing Referer header`);
            request.continue({ headers: cleanHeaders });
          } else {
            logger.info(`   ⛔ No Referer header to apply`);
            request.continue();
          }
        }
      }
    });

    page.on('response', async (response) => {
      const request = response.request();
      const resourceType = request.resourceType();

      if (resourceType === 'document') {
        const url = response.url();
        const status = response.status();
        const headers = response.headers();

        const matchingRequest = redirectChain.find(r => r.url === url);
        const timing = matchingRequest ? Date.now() - matchingRequest.startTime : 0;

        const params = {};
        try {
          const urlObj = new URL(url);
          urlObj.searchParams.forEach((value, key) => {
            params[key] = value;
          });
        } catch (e) {}

        // Track actual response size
        let bandwidthBytes = 0;
        try {
          const isFinalHopTarget = finalHopMinimalMode && finalHopUrl && url.includes(finalHopUrl);
          
          if (isFinalHopTarget) {
            // Minimal mode: skip body download entirely
            bandwidthBytes = 0;
            logger.info(`📄 Browser final URL: ${url} - Minimal mode (skipping body)`);
          } else {
            // Normal mode: download body to extract params
            const buffer = await response.buffer();
            bandwidthBytes = buffer.length;
            const type = status >= 300 && status < 400 ? 'redirect' : 'final URL';
            logger.info(`📄 Browser ${type}: ${url} - Downloaded: ${bandwidthBytes} bytes`);
          }
        } catch (e) {
          // Fallback to Content-Length if buffer fails
          const contentLength = headers['content-length'];
          bandwidthBytes = contentLength ? parseInt(contentLength) : 0;
        }

        let redirectType = 'http';
        const currentStepIndex = chain.length; // Current step number (0-indexed)
        
        if (status >= 300 && status < 400) {
          redirectType = 'http';
          
          // Check if we've reached expected final URL or suffix step - STOP HERE
          // Use hostname matching to avoid false positives from URLs in query params
          let reachedExpectedUrl = false;
          if (expectedFinalUrl) {
            try {
              const urlHostname = new URL(url).hostname.replace(/^www\./, '');
              const expectedHostname = expectedFinalUrl.replace(/^(https?:\/\/)?(www\.)?/, '').split('/')[0];
              reachedExpectedUrl = urlHostname && expectedHostname && 
                                   (urlHostname === expectedHostname);
            } catch (e) {
              // Fallback to simple includes if URL parsing fails
              reachedExpectedUrl = url.includes(expectedFinalUrl);
            }
          }
          const reachedSuffixStep = suffixStep !== null && currentStepIndex >= suffixStep;
          
          if (reachedExpectedUrl || reachedSuffixStep) {
            logger.info(`🛑 Browser: Stopping at step ${currentStepIndex} - ${reachedExpectedUrl ? 'reached expected final URL' : `reached suffix step ${suffixStep}`}`);
            redirectType = 'final';
            bandwidthBytes = 0; // Don't download the body
            
            // Close page immediately to prevent further loading
              pageClosed = true;
            setImmediate(async () => {
              try {
                await page.close();
              } catch (e) {
                logger.error(`Error closing page: ${e.message}`);
              }
            });
          }
        } else if (status >= 200 && status < 300) {
          redirectType = 'final';
          pageClosed = true;
          logger.info(`🛑 Browser: Detected final URL, closing page to save bandwidth`);
          setImmediate(async () => {
            try {
              await page.close();
            } catch (e) {
              logger.error(`Error closing page: ${e.message}`);
            }
          });
        } else {
          redirectType = 'error';
        }

        chain.push({
          url,
          status,
          redirect_type: redirectType,
          method: 'browser',
          headers,
          params,
          timing_ms: timing,
          bandwidth_bytes: bandwidthBytes,
          error: status >= 400 ? `HTTP ${status}` : undefined,
        });
      }
    });

    page.on('popup', async (popup) => {
      const popupIndex = popupChains.length + 1;
      logger.info(`🪟 Browser mode: Popup #${popupIndex} detected!`);

      const openerUrl = page.url();
      const popupChain = [];

      try {
        await popup.waitForNavigation({ timeout: 10000, waitUntil: 'domcontentloaded' }).catch(() => {});
        const popupUrl = popup.url();

        const popupParams = {};
        try {
          const urlObj = new URL(popupUrl);
          urlObj.searchParams.forEach((value, key) => {
            popupParams[key] = value;
          });
        } catch (e) {}

        popupChain.push({
          url: popupUrl,
          status: 200,
          redirect_type: 'popup',
          method: 'window.open',
          params: popupParams,
          timing_ms: 0,
        });

        popupChains.push({
          popup_index: popupIndex,
          opener_url: openerUrl,
          final_url: popupUrl,
          chain: popupChain,
        });

        await popup.close();
      } catch (err) {
        logger.error(`Error handling popup #${popupIndex}:`, err.message);
      }
    });

    // ✅ Limit to 1 attempt: fail fast on navigation errors (no implicit retries)
    const navigationPromise = page.goto(url, {
      waitUntil: 'domcontentloaded',
      timeout,  // Single timeout, no retries
      // NOTE: referer is handled per-hop in the request interceptor based on referrerHops configuration
    }).catch(err => {
      // Catch and log navigation errors without retry
      logger.warn(`⚠️ Browser navigation failed (no retry): ${err.message}`);
      // Don't re-throw - let idle detection handle it
      return null;
    });

    const idleDetectionPromise = new Promise(async (resolve) => {
      let idleCheckInterval;
      
      const checkIdle = async () => {
        const timeSinceLastChange = Date.now() - lastUrlChange;
        // Wait 5 seconds of no URL changes before checking for hidden redirects (increased for meta refresh delays)
        if (timeSinceLastChange > 5000) {
          clearInterval(idleCheckInterval);
          
          // ENHANCED: Search for hidden redirects in HTML BEFORE stopping
          try {
            const hiddenRedirects = await page.evaluate(() => {
              const redirects = [];
              
              // 1. Check URL parameters for redirect targets
              const currentUrl = new URL(window.location.href);
              const urlParam = currentUrl.searchParams.get('url');
              const redirectParam = currentUrl.searchParams.get('redirect');
              const targetParam = currentUrl.searchParams.get('target');
              
              if (urlParam && urlParam.startsWith('http')) {
                redirects.push({ type: 'url_parameter', url: decodeURIComponent(urlParam) });
              } else if (redirectParam && redirectParam.startsWith('http')) {
                redirects.push({ type: 'url_parameter', url: decodeURIComponent(redirectParam) });
              } else if (targetParam && targetParam.startsWith('http')) {
                redirects.push({ type: 'url_parameter', url: decodeURIComponent(targetParam) });
              }
              
              // 2. Check for meta refresh tags
              const metaTags = document.querySelectorAll('meta[http-equiv="refresh"]');
              metaTags.forEach(meta => {
                const content = meta.getAttribute('content') || '';
                const urlMatch = /url=([^;\s]+)/i.exec(content);
                if (urlMatch) {
                  redirects.push({ type: 'meta_refresh', url: urlMatch[1] });
                }
              });
              
              // 3. Check for JavaScript redirect patterns in script tags
              const scripts = document.querySelectorAll('script');
              scripts.forEach(script => {
                const content = script.textContent || '';
                
                // Look for location assignments
                const locationMatches = content.match(/(?:window\.)?location(?:\.href)?\s*=\s*["']([^"']+)["']/i);
                if (locationMatches && locationMatches[1] && locationMatches[1].startsWith('http')) {
                  redirects.push({ type: 'js_location', url: locationMatches[1] });
                }
                
                // Look for location.replace
                const replaceMatches = content.match(/location\.replace\(\s*["']([^"']+)["']\s*\)/i);
                if (replaceMatches && replaceMatches[1] && replaceMatches[1].startsWith('http')) {
                  redirects.push({ type: 'js_replace', url: replaceMatches[1] });
                }
              });
              
              return redirects;
            });
            
            if (hiddenRedirects.length > 0) {
              logger.info(`🔎 Found ${hiddenRedirects.length} hidden redirect(s) in HTML`);
              
              // Follow the first valid redirect
              for (const redirect of hiddenRedirects) {
                logger.info(`  → ${redirect.type}: ${redirect.url}`);
                
                if (redirect.url && redirect.url.startsWith('http')) {
                  try {
                    logger.info(`🔄 Navigating to hidden redirect URL...`);
                    await page.goto(redirect.url, { timeout: 10000, waitUntil: 'domcontentloaded' });
                    lastUrlChange = Date.now();
                    logger.info(`✅ Navigated to: ${page.url()}`);
                    
                    // Wait a bit more and check again
                    await new Promise(r => setTimeout(r, 2000));
                    
                    // Reset idle detection to continue (clear old interval first to prevent duplicates)
                    if (idleCheckInterval) clearInterval(idleCheckInterval);
                    idleCheckInterval = setInterval(checkIdle, 500);
                    return; // Don't resolve yet, continue monitoring
                  } catch (err) {
                    logger.warn(`⚠️ Navigation to hidden redirect failed: ${err.message}`);
                  }
                }
              }
            }
          } catch (err) {
            logger.warn(`⚠️ Error searching for hidden redirects: ${err.message}`);
          }
          
          // Check if all document requests have corresponding responses in chain
          // This prevents closing the page before final 200 status response is added
          const documentRequestCount = requestLog.documentRequests.size;
          const chainEntryCount = chain.length;
          
          if (documentRequestCount > chainEntryCount) {
            logger.info(`⏳ Browser: Waiting for response ${chainEntryCount + 1}/${documentRequestCount} before closing`);
            // Wait a bit more for the response to be added to chain
            await new Promise(r => setTimeout(r, 500));
            lastUrlChange = Date.now(); // Reset idle timer to give response time to process
            return; // Don't close yet, continue monitoring
          }
          
          logger.info('⚡ Browser: Early stop - no more redirects found');
          
          // Close page now to save bandwidth after confirming no more redirects
          if (!pageClosed) {
            pageClosed = true;
            setImmediate(async () => {
              try {
                await page.close();
                logger.info('🛑 Browser: Page closed after idle detection');
              } catch (e) {
                logger.error(`Error closing page after idle: ${e.message}`);
              }
            });
          }
          
          resolve();
        }
      };
      
      idleCheckInterval = setInterval(checkIdle, 500);

      setTimeout(() => {
        clearInterval(idleCheckInterval);
        resolve();
      }, timeout);
    });

    await Promise.race([navigationPromise, idleDetectionPromise]);

    // Get JS redirect log
    let jsRedirectLog = [];
    let formSubmissions = [];
    try {
      jsRedirectLog = await page.evaluate(() => window.__redirectLog || []);
      formSubmissions = await page.evaluate(() => window.__formSubmissions || []);

      
      if (jsRedirectLog.length > 0) {
        logger.info(`🔍 Detected ${jsRedirectLog.length} JS redirect attempts`);
        jsRedirectLog.forEach((log, i) => {
          logger.info(`  ${i + 1}. ${log.type}: ${log.url || 'delayed'}`);
        });
      }
      
      if (formSubmissions.length > 0) {
        logger.info(`📝 Detected ${formSubmissions.length} form submissions`);
        formSubmissions.forEach((form, i) => {
          logger.info(`  ${i + 1}. ${form.method} ${form.action}`);
        });
      }
    } catch (err) {
      logger.warn(`⚠️ Could not retrieve JS redirect log: ${err.message}`);
    }

    const finalUrl = pageClosed ? (chain.length > 0 ? chain[chain.length - 1].url : url) : page.url();
    if (chain.length === 0 || chain[chain.length - 1].url !== finalUrl) {
      const finalParams = {};
      try {
        const urlObj = new URL(finalUrl);
        urlObj.searchParams.forEach((value, key) => {
          finalParams[key] = value;
        });
      } catch (e) {}

      chain.push({
        url: finalUrl,
        status: 200,
        redirect_type: 'final',
        method: 'browser',
        params: finalParams,
        timing_ms: 0,
        bandwidth_bytes: null,
      });
    }

    const totalBandwidth = chain.reduce((sum, entry) => sum + (entry.bandwidth_bytes || 0), 0);
    const avgBandwidth = chain.length > 0 ? totalBandwidth / chain.length : 0;

    // Log network request summary
    const requestDuration = Date.now() - requestLog.startTime;
    const requestRatio = requestLog.documentRequests.size > 0 
      ? (requestLog.totalRequests / requestLog.documentRequests.size).toFixed(2) 
      : 'N/A';
    logger.info(`📊 Browser Mode Network Summary:
  ├─ Document requests: ${requestLog.documentRequests.size}
  ├─ Total network clicks: ${requestLog.totalRequests}
  ├─ Retry attempts detected: ${requestLog.retryAttempts}
  ├─ JS redirects detected: ${jsRedirectLog.length}
  ├─ Form submissions: ${formSubmissions.length}
  ├─ Request ratio (clicks/docs): ${requestRatio}x
  └─ Duration: ${requestDuration}ms`);

    // Extract params from location header based on configuration (optional)
    let locationUrl = null;
    let locationParams = {};
    if (extractFromLocationHeader && chain.length > 0) {
      // Helper to select the redirect entry we should inspect
      const selectRedirectEntry = () => {
        if (locationExtractHop && locationExtractHop > 0 && locationExtractHop <= chain.length) {
          const candidate = chain[locationExtractHop - 1];
          if (candidate && candidate.status >= 300 && candidate.status < 400 && candidate.headers) {
            return candidate;
          }
        }
        return [...chain].reverse().find(entry => entry.status >= 300 && entry.status < 400 && entry.headers);
      };

      const chosenRedirect = selectRedirectEntry();

      if (chosenRedirect && chosenRedirect.headers && chosenRedirect.headers.location) {
        locationUrl = chosenRedirect.headers.location;
        try {
          const urlObj = new URL(locationUrl);
          urlObj.searchParams.forEach((value, key) => {
            locationParams[key] = value;
          });
          logger.info(`📍 Extracted ${Object.keys(locationParams).length} params from location header (hop ${locationExtractHop || 'last redirect'}): ${locationUrl.substring(0, 100)}...`);
        } catch (e) {
          logger.warn(`Could not parse location header as URL: ${e.message}`);
        }
      }
    }

    return {
      success: true,
      chain,
      popup_chains: popupChains,
      total_popups: popupChains.length,
      total_steps: chain.length,
      final_url: finalUrl,
      location_url: extractFromLocationHeader ? locationUrl : undefined,
      location_params: extractFromLocationHeader && Object.keys(locationParams).length > 0 ? locationParams : undefined,
      user_agent: userAgent,
      total_bandwidth_bytes: totalBandwidth,
      bandwidth_per_step_bytes: Math.round(avgBandwidth),
      execution_model: 'browser_full_rendering',
      js_redirects: jsRedirectLog,
      form_submissions: formSubmissions,
      network_stats: {
        total_network_clicks: requestLog.totalRequests,
        document_requests: requestLog.documentRequests.size,
        retry_attempts: requestLog.retryAttempts,
        request_ratio: parseFloat(requestRatio),
        js_redirect_attempts: jsRedirectLog.length,
        form_submission_count: formSubmissions.length,
      },
    };

  } catch (error) {
    logger.error('Browser trace error:', error);

    if (chain.length === 0) {
      chain.push({
        url,
        status: 0,
        redirect_type: 'error',
        method: 'browser',
        error: error.message,
        timing_ms: 0,
        bandwidth_bytes: null,
      });
    }

    const totalBandwidth = chain.reduce((sum, entry) => sum + (entry.bandwidth_bytes || 0), 0);
    const avgBandwidth = chain.length > 0 ? totalBandwidth / chain.length : 0;

    return {
      success: false,
      chain,
      popup_chains: popupChains,
      total_popups: popupChains.length,
      total_steps: chain.length,
      final_url: url,
      error: error.message,
      total_bandwidth_bytes: totalBandwidth,
      bandwidth_per_step_bytes: Math.round(avgBandwidth),
      execution_model: 'browser_full_rendering',
    };
  } finally {
    if (page) {
      await page.close().catch(e => logger.error('Failed to close page:', e));
    }
    // CRITICAL: Close browser after trace to force fresh connection next time
    if (traceBrowser) {
      await traceBrowser.close().catch(e => logger.error('Failed to close browser:', e));
    }
  }
}

async function traceRedirectsAntiCloaking(url, options = {}) {
  const {
    maxRedirects = 20,
    timeout = 90000,
    userAgent = userAgentRotator.getNext(),
    targetCountry = null,
    referrer = null,
    referrerHops = null,
    expectedFinalUrl = null,
    suffixStep = null,
    extractFromLocationHeader = false,
    locationExtractHop = null,
  } = options;

  const chain = [];
  const popupChains = [];
  const obfuscatedUrls = [];
  const cloakingIndicators = [];
  const visitedScriptUrls = new Set();
  const stoppedUrls = new Set();
  const stopOnUrls = new Set();
  const targetHost = expectedFinalUrl ? (() => { try { return new URL(expectedFinalUrl).hostname; } catch (e) { return null; } })() : null;
  let resolveTargetReached = () => {};
  const targetPromise = new Promise((res) => { resolveTargetReached = res; });
  setTimeout(() => resolveTargetReached(), timeout); // safety fallback
  let targetReached = false;
  let traceBrowser = null;
  let page = null;
  let aggressivenessLevel = 'low';
  let latestPageContent = '';

  const normalizeUrl = (candidate) => {
    if (!candidate) return null;
    try {
      const normalized = new URL(candidate, url).toString();
      return normalized.endsWith('/') ? normalized.slice(0, -1) : normalized;
    } catch (e) {
      return null;
    }
  };

  const addStopUrl = (candidate) => {
    const normalized = normalizeUrl(candidate);
    if (normalized) {
      stopOnUrls.add(normalized);
    }
  };

  const shouldStopOnUrl = (candidate) => {
    const normalized = normalizeUrl(candidate);
    if (!normalized) return false;
    if (stopOnUrls.has(normalized) || stopOnUrls.has(normalized.replace(/\/$/, ''))) return true;
    if (targetHost) {
      try {
        return new URL(normalized).hostname === targetHost;
      } catch (e) {
        return false;
      }
    }
    return false;
  };

  addStopUrl(expectedFinalUrl);

  try {
    // Launch FRESH browser per trace - each new browser process = potential new IP
    traceBrowser = await initBrowser(true);
    page = await traceBrowser.newPage();

    if (!proxySettings) {
      await loadProxySettings();
    }

    // CRITICAL: Generate UNIQUE random ID per trace to force fresh Luna connection
    // This matches HTTP-only's approach: new agent/credentials = new IP
    const traceSessionId = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    let proxyUsername = buildProxyUsername(proxySettings.username, targetCountry || null);
    const proxyPassword = proxySettings.password;

    if (targetCountry && targetCountry.length === 2) {
      const countryCode = targetCountry.toLowerCase();
      logger.info(`🕵️ Anti-cloaking: Geo-targeting ${countryCode.toUpperCase()} (session: ${traceSessionId.substring(0, 8)}...)`);
    } else {
      logger.info(`🔄 Anti-cloaking: Fresh Luna connection (session: ${traceSessionId.substring(0, 8)}...)`);
    }

    // MUST authenticate before any requests to ensure Luna sees the username
    await page.authenticate({
      username: proxyUsername,
      password: proxyPassword,
    });

    // CRITICAL: Unique session ID per trace = unique username = fresh Luna connection
    // This forces Luna to treat each trace as a new session, rotating IPs

    await page.setUserAgent(userAgent);
    logger.info(`🕵️ Anti-cloaking User Agent: ${userAgent.substring(0, 80)}...`);
    
    // Generate unique fingerprint per trace - synced with user agent device type
    const fingerprint = generateBrowserFingerprint(userAgent);
    logger.info(`🖥️ Unique fingerprint: ${fingerprint.deviceType} | viewport=${fingerprint.viewport.width}x${fingerprint.viewport.height}, colorDepth=${fingerprint.colorDepth}, pixelRatio=${fingerprint.pixelRatio}`);
    
    await page.setViewport(fingerprint.viewport);

    if (referrer) {
      await page.setExtraHTTPHeaders({
        'Referer': referrer,
        'Accept-Language': fingerprint.language,
        'Accept-Encoding': fingerprint.encoding,
      });
      if (referrerHops && referrerHops.length > 0) {
        logger.info(`🔗 Anti-cloaking using custom referrer on hops ${referrerHops.join(',')}: ${referrer}`);
      } else {
        logger.info(`🔗 Anti-cloaking using custom referrer on ALL hops: ${referrer}`);
      }
    } else {
      await page.setExtraHTTPHeaders({
        'Accept-Language': fingerprint.language,
        'Accept-Encoding': fingerprint.encoding,
      });
    }

    // Use CDP to stop downloading bodies once we hit target URLs (bandwidth savings)
    const client = await page.target().createCDPSession();
    await client.send('Page.enable');
    await client.send('Network.enable');

    client.on('Network.responseReceived', async (event) => {
      if (event.type !== 'Document') return;
      const respUrl = event.response?.url;
      if (shouldStopOnUrl(respUrl)) {
        try {
          await client.send('Page.stopLoading');
          const normalized = normalizeUrl(respUrl);
          if (normalized) {
            stoppedUrls.add(normalized);
          }
          targetReached = true;
          resolveTargetReached();
          logger.info(`🚫 Anti-cloaking: Stopped loading body for target URL ${respUrl.substring(0, 120)}...`);
        } catch (e) {
          logger.warn(`Page.stopLoading failed: ${e.message}`);
        }
      }
    });

    await page.evaluateOnNewDocument(() => {
      Object.defineProperty(navigator, 'webdriver', {
        get: () => undefined,
      });

      window.chrome = {
        runtime: {},
      };

      Object.defineProperty(navigator, 'plugins', {
        get: () => [1, 2, 3, 4, 5],
      });

      Object.defineProperty(navigator, 'languages', {
        get: () => ['en-US', 'en'],
      });

      // Randomize Canvas fingerprint
      const getRandomValues = window.crypto.getRandomValues.bind(window.crypto);
      Object.defineProperty(window.crypto, 'getRandomValues', {
        value: function(typedArray) {
          getRandomValues(typedArray);
          for (let i = 0; i < typedArray.length; i++) {
            typedArray[i] = (typedArray[i] + Math.floor(Math.random() * 256)) % 256;
          }
          return typedArray;
        },
      });

      // Randomize WebGL fingerprint
      const getParameter = WebGLRenderingContext.prototype.getParameter;
      WebGLRenderingContext.prototype.getParameter = function(parameter) {
        if (parameter === 37445) {
          return 'Intel Inc.';
        }
        if (parameter === 37446) {
          return 'Intel Iris OpenGL Engine';
        }
        return getParameter.call(this, parameter);
      };

      const style = document.createElement('style');
      style.textContent = `
        * {
          animation-duration: 0s !important;
          animation-delay: 0s !important;
          transition-duration: 0s !important;
          transition-delay: 0s !important;
        }
      `;
      document.addEventListener('DOMContentLoaded', () => {
        document.head.appendChild(style);
      });

      // Capture top/parent navigation attempts (assign/replace) for later follow-up
      try {
        const hookLocation = (locObj) => {
          if (!locObj) return;
          ['assign', 'replace'].forEach(fn => {
            const original = locObj[fn];
            if (typeof original !== 'function') return;
            Object.defineProperty(locObj, fn, {
              configurable: true,
              value: function(url) {
                try { window.__forcedNavTarget = url; } catch (e) {}
                return original.call(this, url);
              }
            });
          });
        };

        hookLocation(window.top && window.top.location);
        hookLocation(window.parent && window.parent.location);
      } catch (e) {}
    });

    await page.setRequestInterception(true);

    const redirectChain = [];
    let requestCount = 0;
    let lastUrlChange = Date.now();
    
    // Track ALL requests to detect retries
    const requestLog = {
      documentRequests: new Map(),
      totalRequests: 0,
      retryAttempts: 0,
      startTime: Date.now(),
    };

    // Enable minimal mode once we are on the target/final URL to avoid heavy downloads
    let finalHopMinimalMode = false;
    let finalHopUrl = null;
    const activateFinalHopMinimalMode = (triggerUrl, reason) => {
      if (finalHopMinimalMode) return;
      finalHopMinimalMode = true;
      finalHopUrl = triggerUrl;
      logger.info(`🪶 Anti-cloaking: Final-hop minimal mode enabled (${reason}) for ${triggerUrl.substring(0, 80)}...`);
      page.setJavaScriptEnabled(false).catch(err => logger.warn(`Final-hop JS disable failed: ${err.message}`));
    };

    // Capture content after each navigation to avoid context destruction
    page.on('framenavigated', async (frame) => {
      if (frame === page.mainFrame()) {
        lastUrlChange = Date.now();

        // Stop downloading once we reach a configured target URL
        if (shouldStopOnUrl(frame.url())) {
          try {
            await page._client().send('Page.stopLoading');
            targetReached = true;
            resolveTargetReached();
            logger.info(`🚫 Anti-cloaking: Stopped loading after reaching target URL ${frame.url().substring(0, 120)}...`);
          } catch (err) {
            logger.warn(`Stop loading after navigation failed: ${err.message}`);
          }
        }
        
        // Capture content immediately after navigation completes
        try {
          latestPageContent = await page.content();
        } catch (err) {
          // Context may still be destroyed in rapid redirects; ignore
          logger.warn('Could not capture content after navigation:', err.message);
        }
      }
    });

    page.on('request', (request) => {
      const resourceType = request.resourceType();
      const requestUrl = request.url();
      
      requestLog.totalRequests++;

      if (resourceType === 'document') {
        // Check if this matches expected final URL by hostname (not query params)
        if (expectedFinalUrl) {
          try {
            const urlHostname = new URL(requestUrl).hostname.replace(/^www\./, '');
            const expectedHostname = expectedFinalUrl.replace(/^(https?:\/\/)?(www\.)?/, '').split('/')[0];
            // Only match if both hostnames are non-empty to avoid false matches with about:blank
            if (urlHostname && expectedHostname && 
                (urlHostname === expectedHostname)) {
              activateFinalHopMinimalMode(requestUrl, 'expected_final_url_match');
            }
          } catch (e) {
            // Fallback to shouldStopOnUrl if URL parsing fails
            if (shouldStopOnUrl(requestUrl)) {
              activateFinalHopMinimalMode(requestUrl, 'target_url_match');
            }
          }
        } else if (shouldStopOnUrl(requestUrl)) {
          activateFinalHopMinimalMode(requestUrl, 'target_url_match');
        }

        const startTime = Date.now();
        const key = `${request.method()}-${requestUrl}`;
        
        // Check if this document URL was already requested (indicates retry)
        if (requestLog.documentRequests.has(key)) {
          const existing = requestLog.documentRequests.get(key);
          existing.retryCount = (existing.retryCount || 0) + 1;
          requestLog.retryAttempts++;
          logger.warn(`🔄 ANTI-CLOAKING RETRY DETECTED: ${requestUrl} (attempt ${existing.retryCount + 1})`);
        } else {
          requestLog.documentRequests.set(key, {
            url: requestUrl,
            method: request.method(),
            timestamp: Date.now(),
            retryCount: 0,
          });
          logger.info(`📄 Anti-cloaking document request #${requestLog.documentRequests.size}: ${requestUrl}`);
        }
        
        redirectChain.push({
          url: requestUrl,
          method: request.method(),
          headers: request.headers(),
          startTime,
        });
        requestCount++;
      }

      const isBlockedDomain = BLOCKED_DOMAINS.some(domain => requestUrl.includes(domain));
      const finalHopSubresource = finalHopMinimalMode && resourceType !== 'document';
      const shouldBlock = finalHopSubresource || BLOCKED_RESOURCE_TYPES.includes(resourceType) || (isBlockedDomain && resourceType !== 'document');

      if (shouldBlock) {
        request.abort();
      } else {
        // Apply referrer based on referrerHops configuration
        const currentHopNumber = requestLog.documentRequests.size;
        const shouldApplyReferrer = referrer && resourceType === 'document' && (
          !referrerHops || 
          referrerHops.length === 0 || 
          referrerHops.includes(currentHopNumber)
        );
        
        if (resourceType === 'document') {
          const currentHeaders = request.headers();
          const hasReferer = currentHeaders['referer'] || currentHeaders['Referer'];
          logger.info(`🔍 Anti-cloaking Mode - Hop ${currentHopNumber}: referrer=${referrer}, referrerHops=${JSON.stringify(referrerHops)}, shouldApply=${shouldApplyReferrer}`);
          logger.info(`   📋 Current request headers Referer: ${hasReferer || 'NOT SET'}`);
        }
        
        if (shouldApplyReferrer) {
          const overrideHeaders = {
            ...request.headers(),
            'Referer': referrer,
          };
          logger.info(`   ✅ APPLYING Referer header: ${referrer}`);
          request.continue({ headers: overrideHeaders });
        } else {
          // Explicitly remove Referer header if it exists (browser may add it automatically)
          const currentHeaders = request.headers();
          if (currentHeaders['referer'] || currentHeaders['Referer']) {
            const cleanHeaders = { ...currentHeaders };
            delete cleanHeaders['referer'];
            delete cleanHeaders['Referer'];
            logger.info(`   🗑️ REMOVING existing Referer header`);
            request.continue({ headers: cleanHeaders });
          } else {
            logger.info(`   ⛔ No Referer header to apply`);
            request.continue();
          }
        }
      }
    });

    page.on('response', async (response) => {
      const request = response.request();
      const resourceType = request.resourceType();

      if (resourceType === 'document') {
        const url = response.url();
        const status = response.status();
        const headers = response.headers();

        const matchingRequest = redirectChain.find(r => r.url === url);
        const timing = matchingRequest ? Date.now() - matchingRequest.startTime : 0;

        const params = {};
        try {
          const urlObj = new URL(url);
          urlObj.searchParams.forEach((value, key) => {
            params[key] = value;
          });
        } catch (e) {}

        // Track actual response size
        let bandwidthBytes = 0;
        try {
          const isFinalTarget = shouldStopOnUrl(url) || (finalHopMinimalMode && finalHopUrl && url.includes(finalHopUrl));

          if (isFinalTarget) {
            bandwidthBytes = 0; // Skip body for target page
            logger.info(`📄 Anti-cloaking final URL: ${url} - Minimal mode (skipping body)`);
          } else {
            // Normal mode: download body to extract params
            const buffer = await response.buffer();
            bandwidthBytes = buffer.length;
            const type = status >= 300 && status < 400 ? 'redirect' : 'final URL';
            logger.info(`📄 Anti-cloaking ${type}: ${url} - Downloaded: ${bandwidthBytes} bytes`);
          }
        } catch (e) {
          // Fallback to Content-Length if buffer fails
          const contentLength = headers['content-length'];
          bandwidthBytes = contentLength ? parseInt(contentLength) : 0;
        }

        let redirectType = 'http';
        const currentStepIndex = chain.length; // Current step number (0-indexed)
        
        if (status >= 300 && status < 400) {
          redirectType = 'http';
          
          // Check if we've reached expected final URL or suffix step - STOP HERE
          // Use hostname matching to avoid false positives from URLs in query params
          let reachedExpectedUrl = false;
          if (expectedFinalUrl) {
            try {
              const urlHostname = new URL(url).hostname.replace(/^www\./, '');
              const expectedHostname = expectedFinalUrl.replace(/^(https?:\/\/)?(www\.)?/, '').split('/')[0];
              reachedExpectedUrl = urlHostname && expectedHostname && 
                                   (urlHostname === expectedHostname);
            } catch (e) {
              // Fallback to simple includes if URL parsing fails
              reachedExpectedUrl = url.includes(expectedFinalUrl);
            }
          }
          const reachedSuffixStep = suffixStep !== null && currentStepIndex >= suffixStep;
          
          if (reachedExpectedUrl || reachedSuffixStep) {
            logger.info(`🛑 Anti-cloaking: Stopping at step ${currentStepIndex} - ${reachedExpectedUrl ? 'reached expected final URL' : `reached suffix step ${suffixStep}`}`);
            redirectType = 'final';
            bandwidthBytes = 0; // Don't download the body
            
            // Close page immediately to prevent further loading
              pageClosed = true;
            setTimeout(async () => {
              try {
                await page.close();
                pageClosed = true;
                logger.info(`🛑 Anti-cloaking: Closed page at suffix step`);
              } catch (e) {}
            }, 100);
          }
        } else if (status >= 200 && status < 300) {
          redirectType = 'final';
          // CRITICAL: Stop page loading immediately to save bandwidth
          setTimeout(async () => {
            try {
              await page.evaluate(() => window.stop());
              logger.info(`🛑 Anti-cloaking: Stopped loading final page to save bandwidth`);
            } catch (e) {}
          }, 100); // Small delay to ensure response is captured
        } else {
          redirectType = 'error';
        }

        chain.push({
          url,
          status,
          redirect_type: redirectType,
          method: 'anti_cloaking',
          headers,
          params,
          timing_ms: timing,
          bandwidth_bytes: bandwidthBytes,
          error: status >= 400 ? `HTTP ${status}` : undefined,
        });
      }
    });

    page.on('popup', async (popup) => {
      const popupIndex = popupChains.length + 1;
      logger.info(`🪟 Popup #${popupIndex} detected!`);

      let openerUrl = url; // Fallback to initial URL
      try {
        if (!page.isClosed()) {
          openerUrl = page.url();
        }
      } catch (err) {
        logger.warn(`Could not get opener URL: ${err.message}`);
      }
      
      const popupChain = [];

      try {
        await popup.waitForNavigation({ timeout: 10000, waitUntil: 'domcontentloaded' }).catch(() => {});
        const popupUrl = popup.url();

        popupChain.push({
          url: popupUrl,
          status: 200,
          redirect_type: 'popup',
          method: 'window.open',
          timing_ms: 0,
        });

        popupChains.push({
          popup_index: popupIndex,
          opener_url: openerUrl,
          final_url: popupUrl,
          chain: popupChain,
        });

        await popup.close();
      } catch (err) {
        logger.error(`Error handling popup #${popupIndex}:`, err.message);
      }
    });

    // ✅ Limit to 1 attempt: fail fast on navigation errors (no implicit retries)
    const navigationPromise = page.goto(url, {
      waitUntil: 'domcontentloaded',
      timeout,  // Single timeout, no retries
      // NOTE: referer is handled per-hop in the request interceptor based on referrerHops configuration
    }).catch(err => {
      // Catch and log navigation errors without retry
      logger.warn(`⚠️ Anti-cloaking navigation failed (no retry): ${err.message}`);
      // Don't re-throw - let idle detection handle it
      return null;
    });

    const idleDetectionPromise = new Promise((resolve) => {
      const checkIdle = setInterval(() => {
        const timeSinceLastChange = Date.now() - lastUrlChange;
        if (timeSinceLastChange > 3500) {
          clearInterval(checkIdle);
          logger.info('⚡ Anti-cloaking: Early stop - no URL changes for 3.5s');
          resolve();
        }
      }, 500);

      setTimeout(() => {
        clearInterval(checkIdle);
        resolve();
      }, timeout);
    });

    if (stopOnUrls.size > 0 && !finalHopMinimalMode) {
      // Wait for initial navigation, then specifically wait for the target host navigation (bounded)
      // Skip this if minimal mode is already active (it stops page loading immediately)
      await navigationPromise;
      if (targetHost) {
        for (let i = 0; i < 5 && !targetReached; i++) {
          try {
            await page.waitForNavigation({
              timeout: 5000,
              waitUntil: 'domcontentloaded',
              predicate: (nav) => {
                try { return new URL(nav.url()).hostname === targetHost; } catch (e) { return false; }
              },
            });
          } catch (e) {
            // Stop waiting if no further navigations occur within the window
            break;
          }
        }
      }
    } else {
      await Promise.race([navigationPromise, idleDetectionPromise]);
    }

    // Single mouse movement for lightweight human simulation
    try {
      if (!page.isClosed()) {
        await page.mouse.move(150 + Math.random() * 100, 150 + Math.random() * 100);
      }
    } catch (err) {
      logger.warn(`Mouse movement skipped: ${err.message}`);
    }

    // Handle pages that set target_url and redirect via programmatic click
    try {
      if (!page.isClosed()) {
        const scriptRedirect = await page.evaluate(() => {
          try {
            const t = typeof target_url !== 'undefined' ? target_url : null;
            return t && t.trim() ? t.trim() : null;
          } catch (e) {
            return null;
          }
        });

        if (scriptRedirect && !visitedScriptUrls.has(scriptRedirect)) {
          visitedScriptUrls.add(scriptRedirect);
          addStopUrl(scriptRedirect);
          logger.info(`🔀 Anti-cloaking: Following script-defined target_url -> ${scriptRedirect.substring(0, 120)}...`);
          try {
            if (!page.isClosed()) {
              await page.goto(scriptRedirect, { waitUntil: 'domcontentloaded', timeout: Math.min(10000, timeout) });
            }
          } catch (err) {
            logger.warn(`Script redirect navigation failed: ${err.message}`);
          }
        }
      }
    } catch (err) {
      logger.warn(`Script redirect detection error: ${err.message}`);
    }

    // Handle form auto-submit patterns (single follow)
    try {
      if (!page.isClosed()) {
        const formRedirect = await page.evaluate(() => {
          try {
            const forms = Array.from(document.forms || []);
            for (const f of forms) {
              const action = f.getAttribute('action') || f.action;
              if (action && action.trim()) {
                const url = new URL(action, document.baseURI).toString();
                return url;
              }
            }
            return null;
          } catch (e) {
            return null;
          }
        });

        if (formRedirect && !visitedScriptUrls.has(formRedirect)) {
          visitedScriptUrls.add(formRedirect);
          logger.info(`📝 Anti-cloaking: Following form action -> ${formRedirect.substring(0, 120)}...`);
          try {
            if (!page.isClosed()) {
              await page.goto(formRedirect, { waitUntil: 'domcontentloaded', timeout: Math.min(10000, timeout) });
            }
          } catch (err) {
            logger.warn(`Form redirect navigation failed: ${err.message}`);
          }
        }
      }
    } catch (err) {
      logger.warn(`Form redirect detection error: ${err.message}`);
    }

    // Follow captured parent/top navigation attempts
    try {
      if (!page.isClosed()) {
        const forcedNav = await page.evaluate(() => {
          try { return window.__forcedNavTarget || null; } catch (e) { return null; }
        });

        if (forcedNav && !visitedScriptUrls.has(forcedNav)) {
          visitedScriptUrls.add(forcedNav);
          logger.info(`⬆️ Anti-cloaking: Following top/parent redirect -> ${forcedNav.substring(0, 120)}...`);
          try {
            if (!page.isClosed()) {
              await page.goto(forcedNav, { waitUntil: 'domcontentloaded', timeout: Math.min(10000, timeout) });
            }
          } catch (err) {
            logger.warn(`Top/parent redirect navigation failed: ${err.message}`);
          }
        }
      }
    } catch (err) {
      logger.warn(`Top/parent redirect detection error: ${err.message}`);
    }

    // Use captured content if available, otherwise try to get it (with safety fallback)
    let pageContent = latestPageContent;
    if (!pageContent) {
      try {
        if (!page.isClosed()) {
          pageContent = await page.content();
        } else {
          pageContent = '';
        }
      } catch (err) {
        logger.warn('Could not get final page content (context destroyed):', err.message);
        pageContent = '';
      }
    }

    if (pageContent) {
      if (pageContent.includes('data:text/html') || pageContent.includes('atob(') || pageContent.includes('fromCharCode')) {
        cloakingIndicators.push('obfuscated_code');
      }

      if (pageContent.match(/navigator\.webdriver|bot|crawler|spider/i)) {
        cloakingIndicators.push('bot_detection');
      }

      if (pageContent.match(/setTimeout.*redirect|setInterval.*redirect/i)) {
        cloakingIndicators.push('delayed_redirect');
      }

      // Detect meta refresh that opens new windows
      if (pageContent.match(/<meta[^>]+http-equiv=["']?refresh["']?[^>]*>/i)) {
        cloakingIndicators.push('meta_refresh');
      }
    }

    if (popupChains.length > 2) {
      aggressivenessLevel = 'high';
    } else if (popupChains.length > 0 || cloakingIndicators.length > 0) {
      aggressivenessLevel = 'medium';
    }

    let finalUrl = url; // Fallback to initial URL
    try {
      if (!page.isClosed()) {
        finalUrl = page.url();
      } else if (chain.length > 0) {
        finalUrl = chain[chain.length - 1].url;
      }
    } catch (err) {
      logger.warn(`Could not get final URL: ${err.message}`);
      if (chain.length > 0) {
        finalUrl = chain[chain.length - 1].url;
      }
    }
    
    if (chain.length === 0 || chain[chain.length - 1].url !== finalUrl) {
      const finalParams = {};
      try {
        const urlObj = new URL(finalUrl);
        urlObj.searchParams.forEach((value, key) => {
          finalParams[key] = value;
        });
      } catch (e) {}

      chain.push({
        url: finalUrl,
        status: 200,
        redirect_type: 'final',
        method: 'anti_cloaking',
        params: finalParams,
        timing_ms: 0,
        bandwidth_bytes: null,
      });
    }

    const totalBandwidth = chain.reduce((sum, entry) => sum + (entry.bandwidth_bytes || 0), 0);
    const avgBandwidth = chain.length > 0 ? totalBandwidth / chain.length : 0;

    // Log network request summary
    const requestDuration = Date.now() - requestLog.startTime;
    const requestRatio = requestLog.documentRequests.size > 0 
      ? (requestLog.totalRequests / requestLog.documentRequests.size).toFixed(2) 
      : 'N/A';
    logger.info(`📊 Anti-Cloaking Mode Network Summary:
  ├─ Document requests: ${requestLog.documentRequests.size}
  ├─ Total network clicks: ${requestLog.totalRequests}
  ├─ Retry attempts detected: ${requestLog.retryAttempts}
  ├─ Request ratio (clicks/docs): ${requestRatio}x
  └─ Duration: ${requestDuration}ms`);

    // Extract params from location header based on configuration (optional)
    let locationUrl = null;
    let locationParams = {};
    if (extractFromLocationHeader && chain.length > 0) {
      const selectRedirectEntry = () => {
        if (locationExtractHop && locationExtractHop > 0 && locationExtractHop <= chain.length) {
          const candidate = chain[locationExtractHop - 1];
          if (candidate && candidate.status >= 300 && candidate.status < 400 && candidate.headers) {
            return candidate;
          }
        }
        return [...chain].reverse().find(entry => entry.status >= 300 && entry.status < 400 && entry.headers);
      };

      const chosenRedirect = selectRedirectEntry();

      if (chosenRedirect && chosenRedirect.headers && chosenRedirect.headers.location) {
        locationUrl = chosenRedirect.headers.location;
        try {
          const urlObj = new URL(locationUrl);
          urlObj.searchParams.forEach((value, key) => {
            locationParams[key] = value;
          });
          logger.info(`📍 Extracted ${Object.keys(locationParams).length} params from location header (hop ${locationExtractHop || 'last redirect'}): ${locationUrl.substring(0, 100)}...`);
        } catch (e) {
          logger.warn(`Could not parse location header as URL: ${e.message}`);
        }
      }
    }

    return {
      success: true,
      chain,
      popup_chains: popupChains,
      obfuscated_urls: obfuscatedUrls,
      cloaking_indicators: cloakingIndicators,
      aggressiveness_level: aggressivenessLevel,
      total_popups: popupChains.length,
      total_steps: chain.length,
      final_url: finalUrl,
      location_url: extractFromLocationHeader ? locationUrl : undefined,
      location_params: extractFromLocationHeader && Object.keys(locationParams).length > 0 ? locationParams : undefined,
      user_agent: userAgent,
      total_bandwidth_bytes: totalBandwidth,
      bandwidth_per_step_bytes: Math.round(avgBandwidth),
      execution_model: 'anti_cloaking_stealth',
      network_stats: {
        total_network_clicks: requestLog.totalRequests,
        document_requests: requestLog.documentRequests.size,
        retry_attempts: requestLog.retryAttempts,
        request_ratio: parseFloat(requestRatio),
      },
    };

  } catch (error) {
    logger.error('Anti-cloaking trace error:', error);

    if (chain.length === 0) {
      chain.push({
        url,
        status: 0,
        redirect_type: 'error',
        method: 'anti_cloaking',
        error: error.message,
        timing_ms: 0,
        bandwidth_bytes: null,
      });
    }

    const totalBandwidth = chain.reduce((sum, entry) => sum + (entry.bandwidth_bytes || 0), 0);
    const avgBandwidth = chain.length > 0 ? totalBandwidth / chain.length : 0;

    return {
      success: false,
      chain,
      popup_chains: popupChains,
      obfuscated_urls: obfuscatedUrls,
      cloaking_indicators: cloakingIndicators,
      aggressiveness_level: aggressivenessLevel,
      total_popups: popupChains.length,
      total_steps: chain.length,
      final_url: url,
      error: error.message,
      total_bandwidth_bytes: totalBandwidth,
      bandwidth_per_step_bytes: Math.round(avgBandwidth),
      execution_model: 'anti_cloaking_stealth',
    };
  } finally {
    if (page) {
      await page.close().catch(e => logger.error('Failed to close page:', e));
    }
    // CRITICAL: Close browser after trace to force fresh connection next time
    if (traceBrowser) {
      await traceBrowser.close().catch(e => logger.error('Failed to close browser:', e));
    }
  }
}

app.post('/trace', async (req, res) => {
  const startTime = Date.now();

  try {
    const {
      url,
      max_redirects,
      timeout_ms,
      user_agent,
      target_country,
      referrer,
      referrer_hops, // NEW: Array of hop numbers where referrer should be applied [1,2,3] or null for all hops
      mode = 'browser',
      proxy_ip,
      proxy_port,
      follow_http_only,
      geo_pool,
      geo_strategy,
      geo_weights,
      force_country,
      extract_from_location_header = false,
      location_extract_hop = null,
      enable_interactions = false,
      interaction_count = 0,
      bandwidth_limit_kb = null,
      expected_final_url = null,
      suffix_step = null,
      user_id = null,
      offer_id = null,
      debug = false, // NEW: Enable detailed bandwidth calculation only when debug=true
      device_distribution = null, // NEW: Custom device distribution [{ deviceCategory: 'mobile', weight: 60 }, ...]
    } = req.body;

    const normalizedLocationExtractHop = typeof location_extract_hop === 'number'
      ? location_extract_hop
      : (location_extract_hop ? parseInt(location_extract_hop, 10) : null);

    // Apply custom device distribution if provided
    if (device_distribution && Array.isArray(device_distribution) && device_distribution.length > 0) {
      userAgentRotator.setDeviceDistribution(device_distribution);
      logger.info(`📱 Custom device distribution applied for this request: ${JSON.stringify(device_distribution)}`);
    }

    if (!url) {
      return res.status(400).json({ error: 'URL is required' });
    }

    // Debug logging for referrer_hops
    if (referrer) {
      logger.info(`🔗 Trace request received - referrer: ${referrer}, referrer_hops: ${JSON.stringify(referrer_hops)}`);
    }

    logger.info('⚡ Trace request:', {
      url,
      mode,
      max_redirects,
      timeout_ms,
      target_country,
      referrer,
      proxy_ip,
      proxy_port,
      follow_http_only,
      geo_pool,
      geo_strategy,
      geo_weights,
    });

    if (!proxySettings) {
      await loadProxySettings();
    }

    const normalizeCountry = (c) => {
      if (!c || typeof c !== 'string') return null;
      const trimmed = c.trim();
      return trimmed.length === 2 ? trimmed.toLowerCase() : null;
    };

    const sanitizedPool = Array.isArray(geo_pool)
      ? geo_pool.map(normalizeCountry).filter(Boolean)
      : [];

    // Get or create rotator with this configuration
    const rotatorKey = JSON.stringify({ pool: sanitizedPool, strategy: geo_strategy || 'round_robin', weights: geo_weights || {} });
    let rotator = geoRotators.get(rotatorKey);
    if (!rotator && sanitizedPool.length > 0) {
      rotator = new GeoRotator({
        pool: sanitizedPool,
        strategy: geo_strategy || (geo_weights ? 'weighted' : 'round_robin'),
        weights: geo_weights || {},
      });
      geoRotators.set(rotatorKey, rotator);
      logger.info(`🔄 Created new GeoRotator: pool=${sanitizedPool.join(',')}, strategy=${geo_strategy || 'round_robin'}`);
    }

    const forcedCountry = normalizeCountry(force_country);
    const requestCountry = normalizeCountry(target_country);
    const selectedCountry = forcedCountry || requestCountry || (rotator ? rotator.next() : null);

    logger.info('🌍 Geo selection', {
      selected_geo: selectedCountry || null,
      geo_strategy: geo_strategy || (geo_weights ? 'weighted' : 'round_robin'),
      geo_pool_size: sanitizedPool.length,
    });

    const geoUsername = buildProxyUsername(proxy_ip || proxySettings.username, selectedCountry || null, !!proxy_ip);
    if (selectedCountry) {
      logger.info(`🌍 Geo-targeting: ${selectedCountry.toUpperCase()}`);
    }

    const geoPromise = fetchGeolocation(geoUsername, proxySettings.password);

    let tracePromise;
    if (mode === 'http_only') {
      logger.info('⚡ Using HTTP-only mode (fast)');
      tracePromise = traceRedirectsHttpOnly(url, {
        maxRedirects: max_redirects || 20,
        timeout: timeout_ms || 5000,
        userAgent: user_agent || userAgentRotator.getNext(),
        targetCountry: selectedCountry || null,
        referrer: referrer || null,
        referrerHops: referrer_hops || null,
        proxyIp: proxy_ip || null,
        proxyPort: proxy_port || null,
        extractFromLocationHeader: false,
        locationExtractHop: null,
        expectedFinalUrl: expected_final_url || null,
        suffixStep: suffix_step || null,
        debug: debug, // Pass debug flag to tracer
      });
    } else if (mode === 'brightdata_browser') {
      logger.info('🌐 Using Bright Data Browser API mode (cloud browser with geo-targeting)');
      
      // Load API key from database
      let apiKey;
      try {
        apiKey = await loadBrightDataApiKey(user_id, offer_id);
      } catch (err) {
        logger.error('❌ Failed to load Bright Data API key:', err.message);
        return res.status(400).json({ 
          error: 'Bright Data Browser mode requires user_id and a configured provider',
          details: err.message 
        });
      }

      tracePromise = traceRedirectsBrightDataBrowser(url, {
        maxRedirects: max_redirects || 20,
        timeout: timeout_ms || 90000,
        userAgent: user_agent || userAgentRotator.getNext(),
        targetCountry: selectedCountry || null,
        referrer: referrer || null,
        referrerHops: referrer_hops || null,
        apiKey: apiKey,
        // CRITICAL: Pass user context to fix "user context" error
        userContext: {
          user_id: user_id,
          account_id: user_id,
          session_id: `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          provider_id: offer_id,
        },
      });

      // Bright Data handles its own geo/IP, so skip Luna geo lookup
      const [result] = await Promise.all([tracePromise]);

      const totalTime = Date.now() - startTime;
      const bandwidthFormatted = formatBytes(result.total_bandwidth_bytes);
      logger.info(`✅ Trace completed (${mode}): ${result.total_steps} steps in ${totalTime}ms | ${bandwidthFormatted} transferred`);

      return res.json({
        ...result,
        selected_geo: selectedCountry || null,
        geo_strategy_used: geo_strategy || (geo_weights ? 'weighted' : 'round_robin'),
        proxy_used: true,
        proxy_type: 'brightdata_browser',
        proxy_ip: null, // Bright Data doesn't expose individual IPs
        geo_location: {
          country: selectedCountry || 'unknown',
          city: null,
          region: null,
        },
        total_timing_ms: totalTime,
        total_bandwidth_formatted: formatBytes(result.total_bandwidth_bytes),
        mode_used: mode,
      });
    } else if (mode === 'anti_cloaking') {
      logger.info('🕵️ Using Anti-Cloaking mode (advanced stealth)');
      tracePromise = traceRedirectsAntiCloaking(url, {
        maxRedirects: max_redirects || 20,
        timeout: timeout_ms || 90000,
        userAgent: user_agent || userAgentRotator.getNext(),
        targetCountry: selectedCountry || null,
        referrer: referrer || null,
        referrerHops: referrer_hops || null,
        expectedFinalUrl: expected_final_url || null,
        suffixStep: suffix_step || null,
        extractFromLocationHeader: extract_from_location_header || false,
        locationExtractHop: normalizedLocationExtractHop || null,
        debug, // Pass debug flag
      });
    } else if (mode === 'interactive') {
      logger.info('🎬 Using Interactive mode (anti-cloaking + session engagement)');
      tracePromise = traceRedirectsInteractive(url, {
        maxRedirects: max_redirects || 20,
        timeout: timeout_ms || 120000,
        userAgent: user_agent || userAgentRotator.getNext(),
        targetCountry: selectedCountry || null,
        referrer: referrer || null,
        referrerHops: referrer_hops || null,
        extractFromLocationHeader: extract_from_location_header || false,
        locationExtractHop: normalizedLocationExtractHop || null,
        minSessionTime: 4000,
        maxSessionTime: 8000,
      }, puppeteer, generateBrowserFingerprint, BLOCKED_DOMAINS, BLOCKED_RESOURCE_TYPES);
    } else {
      logger.info('🌐 Using Browser mode (full rendering)');
      tracePromise = traceRedirectsBrowser(url, {
        maxRedirects: max_redirects || 20,
        timeout: timeout_ms || 60000,
        userAgent: user_agent || userAgentRotator.getNext(),
        targetCountry: selectedCountry || null,
        referrer: referrer || null,
        referrerHops: referrer_hops || null, // NEW: Pass referrerHops configuration
        expectedFinalUrl: expected_final_url || null,
        suffixStep: suffix_step || null,
        extractFromLocationHeader: extract_from_location_header || false,
        locationExtractHop: normalizedLocationExtractHop || null,
      });
    }

    const [result, geoData] = await Promise.all([tracePromise, geoPromise]);

    const totalTime = Date.now() - startTime;
    
    // Only include bandwidth info if debug=true (reduces response size and processing)
    if (debug) {
      const bandwidthFormatted = formatBytes(result.total_bandwidth_bytes);
      logger.info(`✅ Trace completed (${mode}): ${result.total_steps} steps in ${totalTime}ms | ${bandwidthFormatted} transferred`);
      logger.info(`📊 Bandwidth details: total=${result.total_bandwidth_bytes}B, avg_per_step=${result.bandwidth_per_step_bytes}B`);
    } else {
      logger.info(`✅ Trace completed (${mode}): ${result.total_steps} steps in ${totalTime}ms`);
    }
    
    logger.info(`🌐 Proxy IP used: ${geoData.ip} | Location: ${geoData.city}, ${geoData.region}, ${geoData.country} | Selected Geo: ${selectedCountry ? selectedCountry.toUpperCase() : 'N/A'}`);

    // Build response - only include bandwidth fields if debug=true
    const response = {
      ...result,
      selected_geo: selectedCountry || null,
      geo_strategy_used: geo_strategy || (geo_weights ? 'weighted' : 'round_robin'),
      proxy_used: true,
      proxy_type: 'residential',
      proxy_ip: geoData.ip,
      geo_location: {
        country: geoData.country,
        city: geoData.city,
        region: geoData.region,
      },
      total_timing_ms: totalTime,
      mode_used: mode,
    };
    
    // Add bandwidth fields only in debug mode
    if (debug) {
      response.total_bandwidth_formatted = formatBytes(result.total_bandwidth_bytes);
      response.total_bandwidth_bytes = result.total_bandwidth_bytes;
      response.bandwidth_per_step_bytes = result.bandwidth_per_step_bytes;
    } else {
      // Remove bandwidth fields from result to reduce response size
      delete response.total_bandwidth_bytes;
      delete response.bandwidth_per_step_bytes;
    }
    
    res.json(response);

  } catch (error) {
    logger.error('Request error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Internal server error',
    });
  }
});

app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    browser_initialized: !!browser,
    modes_supported: ['http_only', 'browser', 'anti_cloaking', 'interactive'],
  });
});

app.get('/ip', async (req, res) => {
  try {
    if (!proxySettings) {
      await loadProxySettings();
    }

    const response = await axios.get('https://api.ipify.org?format=json', {
      proxy: {
        host: proxySettings.host,
        port: parseInt(proxySettings.port),
        auth: {
          username: proxySettings.username,
          password: proxySettings.password,
        },
      },
    });

    res.json({
      proxy_ip: response.data.ip,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    logger.error('IP check error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/user-agent-stats', (req, res) => {
  res.json({
    ...userAgentRotator.getStats(),
    description: 'User agent rotation stats - pool refreshes every hour with fresh agents'
  });
});

process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, closing browser...');
  if (browser) {
    await browser.close();
  }
  process.exit(0);
});

process.on('SIGINT', async () => {
  logger.info('SIGINT received, closing browser...');
  if (browser) {
    await browser.close();
  }
  process.exit(0);
});

app.listen(PORT, '0.0.0.0', async () => {
  logger.info(`Proxy service running on 0.0.0.0:${PORT}`);
  logger.info('Supported modes: http_only (fast), browser (full rendering), anti_cloaking (advanced stealth), interactive (anti-cloaking + session engagement)');

  try {
    await loadProxySettings();
    logger.info('Luna Proxy configured from database:', {
      host: proxySettings.host,
      port: proxySettings.port,
    });
  } catch (error) {
    logger.error('Failed to load proxy settings on startup:', error);
  }
});