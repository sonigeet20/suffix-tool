import { useState } from 'react';
import { supabase, Offer, ProxyConfig, TraceResult } from '../lib/supabase';
import {
  X, Save, Play, RefreshCw, AlertCircle, Plus, Trash2,
  Globe, Clock, ArrowRight, CheckCircle, XCircle,
  ChevronDown, ChevronUp, ExternalLink, Copy
} from 'lucide-react';

interface OfferFormProps {
  offer?: Offer;
  onClose: () => void;
  onSave: () => void;
}

export default function OfferForm({ offer, onClose, onSave }: OfferFormProps) {
  const [activeTab, setActiveTab] = useState<'settings' | 'tracer'>('settings');
  const [formData, setFormData] = useState({
    offer_name: offer?.offer_name || '',
    final_url: offer?.final_url || '',
    tracking_template: offer?.tracking_template || '',
    suffix_pattern: offer?.suffix_pattern || '',
    target_geo: offer?.target_geo || '',
    custom_referrer: offer?.custom_referrer || '',
    redirect_chain_step: offer?.redirect_chain_step || 0,
    is_active: offer?.is_active ?? true,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [proxies, setProxies] = useState<ProxyConfig[]>([]);
  const [selectedProxyId, setSelectedProxyId] = useState<string>('');
  const [maxRedirects, setMaxRedirects] = useState<number>(20);
  const [timeout, setTimeout] = useState<number>(30000);
  const [userAgent, setUserAgent] = useState<string>('');
  const [tracing, setTracing] = useState(false);
  const [traceResult, setTraceResult] = useState<TraceResult | null>(null);
  const [traceError, setTraceError] = useState<string | null>(null);
  const [showProxyForm, setShowProxyForm] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [expandedSteps, setExpandedSteps] = useState<Set<number>>(new Set());
  const [selectedStepForSave, setSelectedStepForSave] = useState<number | null>(null);

  const [proxyForm, setProxyForm] = useState({
    name: '',
    proxy_url: '',
    country_code: '',
  });

  useState(() => {
    if (activeTab === 'tracer') {
      fetchProxies();
    }
  });

  const fetchProxies = async () => {
    const { data } = await supabase
      .from('proxy_configs')
      .select('*')
      .order('created_at', { ascending: false });

    if (data) {
      setProxies(data);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      if (offer) {
        const { error } = await supabase
          .from('offers')
          .update(formData)
          .eq('id', offer.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('offers').insert([formData]);
        if (error) throw error;
      }
      onSave();
    } catch (err: any) {
      setError(err.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const executeTrace = async () => {
    if (!formData.tracking_template && !formData.final_url) {
      setTraceError('Please provide a tracking template or final URL');
      return;
    }

    setTracing(true);
    setTraceError(null);
    setTraceResult(null);

    try {
      const url = formData.tracking_template || formData.final_url;
      const proxy = proxies.find(p => p.id === selectedProxyId);

      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const apiUrl = `${supabaseUrl}/functions/v1/trace-redirects`;

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          url,
          proxy_url: proxy?.proxy_url,
          max_redirects: maxRedirects,
          timeout_ms: timeout,
          user_agent: userAgent || undefined,
        }),
      });

      if (!response.ok) {
        throw new Error(`API request failed: ${response.statusText}`);
      }

      const result: TraceResult = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Trace failed');
      }

      setTraceResult(result);

    } catch (err: any) {
      setTraceError(err.message || 'Failed to execute trace');
    } finally {
      setTracing(false);
    }
  };

  const saveStepConfiguration = () => {
    if (selectedStepForSave === null) {
      alert('Please select a step first');
      return;
    }

    setFormData({
      ...formData,
      redirect_chain_step: selectedStepForSave,
    });

    alert('Step configuration updated! Click Save Offer to persist changes.');
    setSelectedStepForSave(null);
  };

  const saveProxy = async () => {
    if (!proxyForm.name || !proxyForm.proxy_url) {
      alert('Name and Proxy URL are required');
      return;
    }

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error: insertError } = await supabase
        .from('proxy_configs')
        .insert({
          user_id: user.id,
          name: proxyForm.name,
          proxy_url: proxyForm.proxy_url,
          country_code: proxyForm.country_code || null,
        });

      if (insertError) throw insertError;

      setProxyForm({ name: '', proxy_url: '', country_code: '' });
      setShowProxyForm(false);
      await fetchProxies();
    } catch (err: any) {
      alert(err.message || 'Failed to save proxy');
    }
  };

  const deleteProxy = async (id: string) => {
    if (!confirm('Delete this proxy configuration?')) return;

    try {
      const { error } = await supabase
        .from('proxy_configs')
        .delete()
        .eq('id', id);

      if (error) throw error;
      await fetchProxies();
    } catch (err: any) {
      alert(err.message || 'Failed to delete proxy');
    }
  };

  const toggleStep = (index: number) => {
    const newExpanded = new Set(expandedSteps);
    if (newExpanded.has(index)) {
      newExpanded.delete(index);
    } else {
      newExpanded.add(index);
    }
    setExpandedSteps(newExpanded);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const getStatusColor = (status: number) => {
    if (status >= 200 && status < 300) return 'bg-green-100 text-green-700';
    if (status >= 300 && status < 400) return 'bg-blue-100 text-blue-700';
    if (status >= 400 && status < 500) return 'bg-orange-100 text-orange-700';
    if (status >= 500) return 'bg-red-100 text-red-700';
    return 'bg-gray-100 text-gray-700';
  };

  const getRedirectTypeColor = (type: string) => {
    switch (type) {
      case 'http': return 'bg-blue-100 text-blue-700';
      case 'meta': return 'bg-purple-100 text-purple-700';
      case 'javascript': return 'bg-yellow-100 text-yellow-700';
      case 'final': return 'bg-green-100 text-green-700';
      case 'error': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-5xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">
            {offer ? 'Edit Offer' : 'Create New Offer'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        <div className="border-b border-gray-200">
          <div className="flex">
            <button
              onClick={() => setActiveTab('settings')}
              className={`px-6 py-3 font-medium text-sm border-b-2 transition-colors ${
                activeTab === 'settings'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              Settings
            </button>
            <button
              onClick={() => {
                setActiveTab('tracer');
                fetchProxies();
              }}
              className={`px-6 py-3 font-medium text-sm border-b-2 transition-colors ${
                activeTab === 'tracer'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              Redirect Tracer
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {activeTab === 'settings' ? (
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
                  {error}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Offer Name
                </label>
                <input
                  type="text"
                  value={formData.offer_name}
                  onChange={(e) =>
                    setFormData({ ...formData, offer_name: e.target.value })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Final URL
                </label>
                <input
                  type="url"
                  value={formData.final_url}
                  onChange={(e) =>
                    setFormData({ ...formData, final_url: e.target.value })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tracking Template
                </label>
                <input
                  type="url"
                  value={formData.tracking_template}
                  onChange={(e) =>
                    setFormData({ ...formData, tracking_template: e.target.value })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  placeholder="Optional"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Suffix Pattern
                </label>
                <input
                  type="text"
                  value={formData.suffix_pattern}
                  onChange={(e) =>
                    setFormData({ ...formData, suffix_pattern: e.target.value })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Target Geo
                  </label>
                  <input
                    type="text"
                    value={formData.target_geo}
                    onChange={(e) =>
                      setFormData({ ...formData, target_geo: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    placeholder="e.g., US, UK"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Redirect Chain Step
                  </label>
                  <input
                    type="number"
                    value={formData.redirect_chain_step}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        redirect_chain_step: parseInt(e.target.value) || 0,
                      })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                    min="0"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Custom Referrer
                </label>
                <input
                  type="text"
                  value={formData.custom_referrer}
                  onChange={(e) =>
                    setFormData({ ...formData, custom_referrer: e.target.value })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  placeholder="Optional"
                />
              </div>

              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="is_active"
                  checked={formData.is_active}
                  onChange={(e) =>
                    setFormData({ ...formData, is_active: e.target.checked })
                  }
                  className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                />
                <label htmlFor="is_active" className="text-sm font-medium text-gray-700">
                  Active
                </label>
              </div>

              <div className="flex gap-3 pt-4 border-t border-gray-200">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium flex items-center justify-center gap-2"
                >
                  <Save size={18} />
                  {loading ? 'Saving...' : 'Save Offer'}
                </button>
              </div>
            </form>
          ) : (
            <div className="p-6 space-y-6">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-900">
                  Test your tracking template and configure which redirect step to extract parameters from.
                  Make sure to save the offer after configuring the redirect chain step.
                </p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Proxy Configuration (Optional)
                  </label>
                  <div className="flex gap-2">
                    <select
                      value={selectedProxyId}
                      onChange={(e) => setSelectedProxyId(e.target.value)}
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="">-- No Proxy --</option>
                      {proxies.map((proxy) => (
                        <option key={proxy.id} value={proxy.id}>
                          {proxy.name} {proxy.country_code ? `(${proxy.country_code})` : ''}
                        </option>
                      ))}
                    </select>
                    <button
                      type="button"
                      onClick={() => setShowProxyForm(!showProxyForm)}
                      className="px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                    >
                      <Plus size={18} />
                    </button>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setShowAdvanced(!showAdvanced)}
                  className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900"
                >
                  {showAdvanced ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                  Advanced Settings
                </button>

                {showAdvanced && (
                  <div className="grid grid-cols-3 gap-4 pt-2">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Max Redirects
                      </label>
                      <input
                        type="number"
                        value={maxRedirects}
                        onChange={(e) => setMaxRedirects(parseInt(e.target.value))}
                        min="1"
                        max="50"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Timeout (ms)
                      </label>
                      <input
                        type="number"
                        value={timeout}
                        onChange={(e) => setTimeout(parseInt(e.target.value))}
                        min="5000"
                        max="60000"
                        step="1000"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        User Agent (Optional)
                      </label>
                      <input
                        type="text"
                        value={userAgent}
                        onChange={(e) => setUserAgent(e.target.value)}
                        placeholder="Default Chrome UA"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                  </div>
                )}

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={executeTrace}
                    disabled={tracing}
                    className="flex items-center gap-2 px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed font-medium"
                  >
                    {tracing ? (
                      <>
                        <RefreshCw size={18} className="animate-spin" />
                        Tracing...
                      </>
                    ) : (
                      <>
                        <Play size={18} />
                        Execute Trace
                      </>
                    )}
                  </button>

                  {traceResult && selectedStepForSave !== null && (
                    <button
                      type="button"
                      onClick={saveStepConfiguration}
                      className="flex items-center gap-2 px-6 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
                    >
                      <Save size={18} />
                      Use Step {selectedStepForSave + 1}
                    </button>
                  )}
                </div>
              </div>

              {showProxyForm && (
                <div className="bg-gray-50 rounded-lg p-4 space-y-4">
                  <h4 className="font-semibold text-gray-900">Add Proxy Configuration</h4>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Proxy Name
                    </label>
                    <input
                      type="text"
                      value={proxyForm.name}
                      onChange={(e) => setProxyForm({ ...proxyForm, name: e.target.value })}
                      placeholder="US Proxy - Provider Name"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Proxy URL
                    </label>
                    <input
                      type="text"
                      value={proxyForm.proxy_url}
                      onChange={(e) => setProxyForm({ ...proxyForm, proxy_url: e.target.value })}
                      placeholder="http://username:password@proxy-host:port"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Country Code (Optional)
                    </label>
                    <input
                      type="text"
                      value={proxyForm.country_code}
                      onChange={(e) => setProxyForm({ ...proxyForm, country_code: e.target.value })}
                      placeholder="US, UK, CA, etc."
                      maxLength={2}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={saveProxy}
                      className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                    >
                      <Save size={18} />
                      Save Proxy
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setShowProxyForm(false);
                        setProxyForm({ name: '', proxy_url: '', country_code: '' });
                      }}
                      className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}

              {proxies.length > 0 && (
                <div className="space-y-2">
                  <h4 className="font-semibold text-gray-900">Saved Proxies</h4>
                  {proxies.map((proxy) => (
                    <div
                      key={proxy.id}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                    >
                      <div className="flex items-center gap-3">
                        <Globe size={18} className="text-gray-400" />
                        <div>
                          <p className="font-medium text-gray-900">{proxy.name}</p>
                          <p className="text-xs text-gray-500 font-mono truncate max-w-md">
                            {proxy.proxy_url}
                          </p>
                        </div>
                        {proxy.country_code && (
                          <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs font-medium rounded">
                            {proxy.country_code}
                          </span>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={() => deleteProxy(proxy.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {traceError && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
                  <AlertCircle className="text-red-600 flex-shrink-0" size={20} />
                  <div>
                    <p className="font-medium text-red-900">Trace Error</p>
                    <p className="text-red-700 text-sm mt-1">{traceError}</p>
                  </div>
                </div>
              )}

              {traceResult && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-semibold text-gray-900">Trace Results</h4>
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-2">
                        <Clock size={16} className="text-gray-400" />
                        <span className="text-gray-600">
                          {traceResult.total_timing_ms}ms
                        </span>
                      </div>
                      <span className="text-gray-600">
                        {traceResult.total_steps} steps
                      </span>
                    </div>
                  </div>

                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {traceResult.chain.map((step, index) => {
                      const isExpanded = expandedSteps.has(index);
                      const isSavedStep = formData.redirect_chain_step === index;

                      return (
                        <div
                          key={index}
                          className={`border-2 rounded-lg transition-all ${
                            selectedStepForSave === index
                              ? 'border-green-500 bg-green-50'
                              : isSavedStep
                              ? 'border-blue-500 bg-blue-50'
                              : 'border-gray-200 bg-white'
                          }`}
                        >
                          <button
                            type="button"
                            onClick={() => toggleStep(index)}
                            className="w-full p-4 text-left"
                          >
                            <div className="flex items-start justify-between gap-4">
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-3 mb-2">
                                  <span className="font-semibold text-gray-900">
                                    Step {index + 1}
                                  </span>
                                  <span className={`px-2 py-1 text-xs font-medium rounded ${getStatusColor(step.status)}`}>
                                    {step.status || 'N/A'}
                                  </span>
                                  <span className={`px-2 py-1 text-xs font-medium rounded ${getRedirectTypeColor(step.redirect_type)}`}>
                                    {step.redirect_type}
                                  </span>
                                  {selectedStepForSave === index && (
                                    <span className="px-2 py-1 bg-green-600 text-white text-xs font-medium rounded">
                                      SELECTED
                                    </span>
                                  )}
                                  {isSavedStep && (
                                    <span className="px-2 py-1 bg-blue-600 text-white text-xs font-medium rounded">
                                      SAVED
                                    </span>
                                  )}
                                </div>
                                <div className="flex items-center gap-2 text-sm">
                                  <ExternalLink size={14} className="text-gray-400 flex-shrink-0" />
                                  <span className="text-gray-700 truncate font-mono text-xs">
                                    {step.url}
                                  </span>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      copyToClipboard(step.url);
                                    }}
                                    className="p-1 text-gray-400 hover:text-gray-600"
                                  >
                                    <Copy size={12} />
                                  </button>
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                {step.params && Object.keys(step.params).length > 0 && (
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setSelectedStepForSave(selectedStepForSave === index ? null : index);
                                    }}
                                    className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                                      selectedStepForSave === index
                                        ? 'bg-green-600 text-white'
                                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                    }`}
                                  >
                                    {selectedStepForSave === index ? 'Selected' : 'Select'}
                                  </button>
                                )}
                                {isExpanded ? (
                                  <ChevronUp size={20} className="text-gray-400" />
                                ) : (
                                  <ChevronDown size={20} className="text-gray-400" />
                                )}
                              </div>
                            </div>
                          </button>

                          {isExpanded && (
                            <div className="px-4 pb-4 space-y-3 border-t border-gray-200">
                              {step.params && Object.keys(step.params).length > 0 && (
                                <div>
                                  <p className="text-sm font-semibold text-gray-700 mb-2">
                                    Parameters ({Object.keys(step.params).length})
                                  </p>
                                  <div className="bg-gray-50 rounded p-3 space-y-1 max-h-40 overflow-y-auto">
                                    {Object.entries(step.params).map(([key, value]) => (
                                      <div key={key} className="flex gap-3 text-xs font-mono">
                                        <span className="font-semibold text-gray-700 min-w-[120px]">
                                          {key}:
                                        </span>
                                        <span className="text-gray-900 break-all">{value}</span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}

                              {step.headers && Object.keys(step.headers).length > 0 && (
                                <div>
                                  <p className="text-sm font-semibold text-gray-700 mb-2">
                                    Headers
                                  </p>
                                  <div className="bg-gray-50 rounded p-3 space-y-1 max-h-40 overflow-y-auto">
                                    {Object.entries(step.headers).slice(0, 5).map(([key, value]) => (
                                      <div key={key} className="flex gap-3 text-xs font-mono">
                                        <span className="font-semibold text-gray-700 min-w-[120px]">
                                          {key}:
                                        </span>
                                        <span className="text-gray-900 break-all truncate">{value}</span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          )}

                          {index < traceResult.chain.length - 1 && (
                            <div className="flex justify-center py-2">
                              <ArrowRight size={20} className="text-blue-500 transform rotate-90" />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      {traceResult.chain[traceResult.chain.length - 1].redirect_type === 'final' ? (
                        <CheckCircle className="text-green-600" size={20} />
                      ) : (
                        <XCircle className="text-red-600" size={20} />
                      )}
                      <span className="font-semibold text-gray-900">Final Destination:</span>
                    </div>
                    <code className="block bg-white px-3 py-2 rounded text-sm font-mono text-gray-900 break-all">
                      {traceResult.final_url}
                    </code>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
