import { useEffect, useState } from 'react';
import { supabase, Offer } from '../lib/supabase';
import { Plus, Edit, Trash2, Link2, ExternalLink, Copy, CheckCircle, ChevronDown, ChevronUp, ArrowRight } from 'lucide-react';
import OfferForm from './OfferForm';

export default function OfferList() {
  const [offers, setOffers] = useState<Offer[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingOffer, setEditingOffer] = useState<Offer | undefined>();
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [expandedTraces, setExpandedTraces] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchOffers();
  }, []);

  const fetchOffers = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('offers')
      .select('*')
      .order('created_at', { ascending: false });

    if (!error && data) {
      setOffers(data);
    }
    setLoading(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this offer?')) return;

    const { error } = await supabase.from('offers').delete().eq('id', id);
    if (!error) {
      fetchOffers();
    }
  };

  const handleEdit = (offer: Offer) => {
    setEditingOffer(offer);
    setShowForm(true);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingOffer(undefined);
  };

  const handleSave = () => {
    fetchOffers();
    handleCloseForm();
  };

  const getApiUrl = (offerName: string) => {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    return `${supabaseUrl}/functions/v1/get-suffix?offer_name=${encodeURIComponent(offerName)}`;
  };

  const copyToClipboard = async (offerId: string, url: string) => {
    await navigator.clipboard.writeText(url);
    setCopiedId(offerId);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const toggleTraceExpanded = (offerId: string) => {
    const newExpanded = new Set(expandedTraces);
    if (newExpanded.has(offerId)) {
      newExpanded.delete(offerId);
    } else {
      newExpanded.add(offerId);
    }
    setExpandedTraces(newExpanded);
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'Never';
    return new Date(dateString).toLocaleString();
  };

  if (loading) {
    return (
      <div className="text-center py-12 text-gray-500">Loading offers...</div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Your Offers</h2>
          <p className="text-gray-600 mt-1">Manage your URL tracking offers</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
        >
          <Plus size={20} />
          New Offer
        </button>
      </div>

      {offers.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
          <Link2 className="mx-auto text-gray-400 mb-4" size={48} />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            No offers yet
          </h3>
          <p className="text-gray-600 mb-6">
            Create your first offer to start tracking URLs
          </p>
          <button
            onClick={() => setShowForm(true)}
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            <Plus size={20} />
            Create First Offer
          </button>
        </div>
      ) : (
        <div className="grid gap-4">
          {offers.map((offer) => {
            const apiUrl = getApiUrl(offer.offer_name);
            return (
              <div
                key={offer.id}
                className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-gray-900">
                        {offer.offer_name}
                      </h3>
                      {offer.is_active ? (
                        <span className="px-2 py-1 bg-green-100 text-green-700 text-xs font-medium rounded">
                          Active
                        </span>
                      ) : (
                        <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs font-medium rounded">
                          Inactive
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <ExternalLink size={14} />
                      <a
                        href={offer.final_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:text-blue-600 truncate max-w-md"
                      >
                        {offer.final_url}
                      </a>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleEdit(offer)}
                      className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      <Edit size={18} />
                    </button>
                    <button
                      onClick={() => handleDelete(offer.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex items-start gap-2">
                    <span className="text-gray-500 font-medium min-w-[140px]">
                      Suffix Pattern:
                    </span>
                    <code className="bg-gray-100 px-2 py-1 rounded text-gray-800 font-mono">
                      {offer.suffix_pattern || '(none)'}
                    </code>
                  </div>

                  {offer.tracking_template && (
                    <div className="flex items-start gap-2">
                      <span className="text-gray-500 font-medium min-w-[140px]">
                        Tracking Template:
                      </span>
                      <span className="text-gray-700 truncate">
                        {offer.tracking_template}
                      </span>
                    </div>
                  )}

                  {offer.target_geo && (
                    <div className="flex items-start gap-2">
                      <span className="text-gray-500 font-medium min-w-[140px]">
                        Target Geo:
                      </span>
                      <span className="text-gray-700">{offer.target_geo}</span>
                    </div>
                  )}

                  <div className="flex items-start gap-2 pt-2 border-t border-gray-200">
                    <span className="text-gray-500 font-medium min-w-[140px]">
                      API Endpoint:
                    </span>
                    <div className="flex-1 flex items-center gap-2">
                      <code className="flex-1 bg-blue-50 px-2 py-1 rounded text-blue-800 font-mono text-xs truncate">
                        {apiUrl}
                      </code>
                      <button
                        onClick={() => copyToClipboard(offer.id, apiUrl)}
                        className="p-1.5 text-gray-600 hover:bg-gray-100 rounded transition-colors"
                        title="Copy to clipboard"
                      >
                        {copiedId === offer.id ? (
                          <CheckCircle size={16} className="text-green-600" />
                        ) : (
                          <Copy size={16} />
                        )}
                      </button>
                    </div>
                  </div>

                  {offer.tracking_template && (
                    <div className="mt-3 pt-3 border-t border-gray-200">
                      <button
                        onClick={() => toggleTraceExpanded(offer.id)}
                        className="w-full flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg transition-colors"
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-gray-500 font-medium">
                            Redirect Chain Trace
                          </span>
                          {offer.last_trace_date && (
                            <span className="text-xs text-gray-400">
                              (Last traced: {formatDate(offer.last_trace_date)})
                            </span>
                          )}
                        </div>
                        {expandedTraces.has(offer.id) ? (
                          <ChevronUp size={16} className="text-gray-400" />
                        ) : (
                          <ChevronDown size={16} className="text-gray-400" />
                        )}
                      </button>

                      {expandedTraces.has(offer.id) && (
                        <div className="mt-2 bg-gray-50 rounded-lg p-3">
                          {!offer.last_traced_chain || offer.last_traced_chain.length === 0 ? (
                            <p className="text-xs text-gray-500 italic">
                              No trace data yet. Call the get-suffix API to trace the redirect chain.
                            </p>
                          ) : (
                            <div className="space-y-2">
                              <div className="flex items-center gap-2 mb-2">
                                <span className="text-xs font-semibold text-gray-700">
                                  Redirect Chain Steps:
                                </span>
                                <span className="text-xs text-gray-500">
                                  ({offer.last_traced_chain.length} {offer.last_traced_chain.length === 1 ? 'step' : 'steps'})
                                </span>
                              </div>
                              {offer.last_traced_chain.map((step: any, index: number) => (
                                <div
                                  key={index}
                                  className={`relative pl-6 pb-3 ${
                                    index < offer.last_traced_chain!.length - 1 ? 'border-l-2 border-blue-300' : ''
                                  }`}
                                >
                                  <div className="absolute left-0 top-0 -ml-1 w-2 h-2 rounded-full bg-blue-500"></div>
                                  <div className="bg-white rounded-lg p-3 border border-gray-200">
                                    <div className="flex items-start justify-between gap-2 mb-2">
                                      <div className="flex items-center gap-2">
                                        <span className="text-xs font-semibold text-gray-700">
                                          Step {index + 1}
                                        </span>
                                        {index === offer.redirect_chain_step && (
                                          <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs font-medium rounded">
                                            Params Extracted
                                          </span>
                                        )}
                                      </div>
                                      <div className="flex items-center gap-2">
                                        <span className={`px-2 py-0.5 text-xs font-medium rounded ${
                                          step.status >= 200 && step.status < 300
                                            ? 'bg-green-100 text-green-700'
                                            : step.status >= 300 && step.status < 400
                                            ? 'bg-blue-100 text-blue-700'
                                            : 'bg-red-100 text-red-700'
                                        }`}>
                                          {step.status}
                                        </span>
                                        <span className="px-2 py-0.5 bg-gray-100 text-gray-700 text-xs font-medium rounded">
                                          {step.redirect_type}
                                        </span>
                                      </div>
                                    </div>
                                    <div className="text-xs text-gray-600 break-all mb-2">
                                      {step.url}
                                    </div>
                                    {step.params && Object.keys(step.params).length > 0 && (
                                      <div className="mt-2 pt-2 border-t border-gray-200">
                                        <span className="text-xs font-semibold text-gray-700">Parameters:</span>
                                        <div className="mt-1 space-y-1">
                                          {Object.entries(step.params).map(([key, value]: [string, any]) => (
                                            <div key={key} className="flex gap-2 text-xs">
                                              <span className="font-medium text-gray-600">{key}:</span>
                                              <span className="text-gray-800">{value}</span>
                                            </div>
                                          ))}
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                  {index < offer.last_traced_chain!.length - 1 && (
                                    <div className="absolute left-0 bottom-0 -ml-1">
                                      <ArrowRight size={14} className="text-blue-500 transform rotate-90" />
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showForm && (
        <OfferForm
          offer={editingOffer}
          onClose={handleCloseForm}
          onSave={handleSave}
        />
      )}
    </div>
  );
}
