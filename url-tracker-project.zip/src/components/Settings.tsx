import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Settings as SettingsIcon, Save, AlertCircle, CheckCircle } from 'lucide-react';

interface ProxySettings {
  id?: string;
  proxy_provider: string;
  proxy_host: string;
  proxy_port: number;
  proxy_username: string;
  proxy_password: string;
}

export default function Settings() {
  const [settings, setSettings] = useState<ProxySettings>({
    proxy_provider: '',
    proxy_host: '',
    proxy_port: 8080,
    proxy_username: '',
    proxy_password: '',
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('settings')
      .select('*')
      .maybeSingle();

    if (!error && data) {
      setSettings(data);
    }
    setLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage(null);

    try {
      if (settings.id) {
        const { error } = await supabase
          .from('settings')
          .update(settings)
          .eq('id', settings.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('settings').insert([settings]);
        if (error) throw error;
      }
      setMessage({ type: 'success', text: 'Settings saved successfully!' });
      await fetchSettings();
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Failed to save settings' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="text-center py-12 text-gray-500">Loading settings...</div>
    );
  }

  return (
    <div className="max-w-3xl">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center gap-2 mb-6">
          <SettingsIcon className="text-blue-600" size={24} />
          <h2 className="text-xl font-bold text-gray-900">Proxy Settings</h2>
        </div>

        {message && (
          <div
            className={`mb-6 p-4 rounded-lg flex items-center gap-2 ${
              message.type === 'success'
                ? 'bg-green-50 border border-green-200 text-green-700'
                : 'bg-red-50 border border-red-200 text-red-700'
            }`}
          >
            {message.type === 'success' ? (
              <CheckCircle size={18} />
            ) : (
              <AlertCircle size={18} />
            )}
            <span>{message.text}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Proxy Provider
            </label>
            <input
              type="text"
              value={settings.proxy_provider}
              onChange={(e) =>
                setSettings({ ...settings, proxy_provider: e.target.value })
              }
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              placeholder="e.g., BrightData, Oxylabs"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Proxy Host
            </label>
            <input
              type="text"
              value={settings.proxy_host}
              onChange={(e) =>
                setSettings({ ...settings, proxy_host: e.target.value })
              }
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              placeholder="proxy.example.com"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Proxy Port
            </label>
            <input
              type="number"
              value={settings.proxy_port}
              onChange={(e) =>
                setSettings({ ...settings, proxy_port: parseInt(e.target.value) || 8080 })
              }
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              placeholder="8080"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Proxy Username
            </label>
            <input
              type="text"
              value={settings.proxy_username}
              onChange={(e) =>
                setSettings({ ...settings, proxy_username: e.target.value })
              }
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              placeholder="your-username"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Proxy Password
            </label>
            <input
              type="password"
              value={settings.proxy_password}
              onChange={(e) =>
                setSettings({ ...settings, proxy_password: e.target.value })
              }
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              placeholder="your-password"
            />
          </div>

          <div className="pt-4">
            <button
              type="submit"
              disabled={saving}
              className="w-full px-4 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium flex items-center justify-center gap-2"
            >
              <Save size={18} />
              {saving ? 'Saving...' : 'Save Settings'}
            </button>
          </div>
        </form>
      </div>

      <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="text-sm font-semibold text-blue-900 mb-2">
          About Proxy Settings
        </h3>
        <p className="text-sm text-blue-800">
          Configure your proxy settings to enable URL tracking through proxies. These
          settings are used when tracing tracking templates to extract URL parameters.
          Leave fields empty if you don't use a proxy service.
        </p>
      </div>
    </div>
  );
}
