import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface ProxyConfig {
  provider: string;
  host: string;
  port: number;
  username: string;
  password: string;
  country?: string;
}

interface RedirectStep {
  url: string;
  status: number;
  redirect_type: string;
  params: Record<string, string>;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const url = new URL(req.url);
    const offerName = url.searchParams.get('offer_name');

    if (!offerName) {
      return new Response(
        JSON.stringify({ error: 'offer_name parameter is required' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const { data: offer, error: offerError } = await supabase
      .from('offers')
      .select('*')
      .eq('offer_name', offerName)
      .eq('is_active', true)
      .maybeSingle();

    if (offerError || !offer) {
      return new Response(
        JSON.stringify({ error: 'Offer not found or inactive' }),
        {
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    let finalSuffix = offer.suffix_pattern || '';

    if (offer.tracking_template) {
      const { data: settings } = await supabase
        .from('settings')
        .select('*')
        .maybeSingle();

      if (settings && settings.proxy_host && settings.proxy_username && settings.proxy_password) {
        try {
          const proxyConfig: ProxyConfig = {
            provider: settings.proxy_provider,
            host: settings.proxy_host,
            port: settings.proxy_port,
            username: settings.proxy_username,
            password: settings.proxy_password,
            country: offer.target_geo || '',
          };

          const chain = await traceUrlWithProxy(
            offer.tracking_template,
            proxyConfig,
            offer.custom_referrer || ''
          );

          if (chain && chain.length > 0) {
            let targetStep = chain[chain.length - 1];
            
            if (offer.redirect_chain_step >= 0 && offer.redirect_chain_step < chain.length) {
              targetStep = chain[offer.redirect_chain_step];
            }

            if (targetStep && targetStep.params) {
              const params = new URLSearchParams(targetStep.params);
              finalSuffix = params.toString();
            }
          }

          await supabase.from('offers').update({
            last_traced_chain: chain,
            last_trace_date: new Date().toISOString(),
          }).eq('id', offer.id);
        } catch (traceError: any) {
          console.error('Error tracing URL:', traceError);
          finalSuffix = offer.suffix_pattern || '';
        }
      } else {
        console.warn('Proxy not configured, using fallback suffix');
        finalSuffix = offer.suffix_pattern || '';
      }
    }

    const clientIp = req.headers.get('x-forwarded-for') || 'unknown';
    const userAgent = req.headers.get('user-agent') || 'unknown';
    const wasTraced = !!offer.tracking_template && finalSuffix !== (offer.suffix_pattern || '');

    await supabase.from('suffix_requests').insert({
      offer_id: offer.id,
      suffix_returned: finalSuffix,
      ip_address: clientIp,
      user_agent: userAgent,
    });

    const { data: currentStats } = await supabase
      .from('offer_statistics')
      .select('*')
      .eq('offer_id', offer.id)
      .maybeSingle();

    const newStats = {
      offer_id: offer.id,
      total_suffix_requests: (currentStats?.total_suffix_requests || 0) + 1,
      total_tracking_hits: (currentStats?.total_tracking_hits || 0) + (wasTraced ? 1 : 0),
      last_request_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    await supabase
      .from('offer_statistics')
      .upsert(newStats, { onConflict: 'offer_id' });

    return new Response(
      JSON.stringify({
        success: true,
        offer_name: offer.offer_name,
        final_url: offer.final_url,
        tracking_template: offer.tracking_template,
        suffix: finalSuffix,
        traced_fresh: !!offer.tracking_template,
        timestamp: new Date().toISOString(),
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error: any) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error', message: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

async function traceUrlWithProxy(
  trackingUrl: string,
  proxyConfig: ProxyConfig,
  customReferrer: string
): Promise<RedirectStep[]> {
  const chain: RedirectStep[] = [];
  let currentUrl = trackingUrl;
  let maxRedirects = 20;
  let redirectCount = 0;

  while (redirectCount < maxRedirects) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000);

      const fetchHeaders: Record<string, string> = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
      };

      if (customReferrer) {
        fetchHeaders["Referer"] = customReferrer;
      } else if (redirectCount > 0) {
        const previousUrl = chain[chain.length - 1]?.url;
        if (previousUrl) {
          fetchHeaders["Referer"] = previousUrl;
        }
      }

      const fetchOptions: RequestInit = {
        method: "GET",
        redirect: "manual",
        signal: controller.signal,
        headers: fetchHeaders,
      };

      const response = await fetch(currentUrl, fetchOptions);
      clearTimeout(timeoutId);

      const parsedUrl = new URL(currentUrl);
      const params: Record<string, string> = {};
      parsedUrl.searchParams.forEach((value, key) => {
        params[key] = value;
      });

      const status = response.status;
      let redirectType = "final";
      let nextUrl: string | null = null;

      if (status >= 300 && status < 400) {
        redirectType = "http";
        nextUrl = response.headers.get("location");
        if (nextUrl && !nextUrl.startsWith("http")) {
          nextUrl = new URL(nextUrl, currentUrl).toString();
        }
      } else if (status === 200) {
        const body = await response.text();

        const metaRefreshMatch = body.match(
          /<meta[^>]*http-equiv=["']refresh["'][^>]*content=["']\d+;\s*url=([^"']+)["'][^>]*>/i
        );
        if (metaRefreshMatch && metaRefreshMatch[1]) {
          redirectType = "meta";
          nextUrl = metaRefreshMatch[1];
          if (!nextUrl.startsWith("http")) {
            nextUrl = new URL(nextUrl, currentUrl).toString();
          }
        }

        const jsRedirectMatch =
          body.match(/window\.location(?:\.href)?\s*=\s*["']([^"']+)["']/i) ||
          body.match(/document\.location(?:\.href)?\s*=\s*["']([^"']+)["']/i);
        if (!nextUrl && jsRedirectMatch && jsRedirectMatch[1]) {
          redirectType = "javascript";
          nextUrl = jsRedirectMatch[1];
          if (!nextUrl.startsWith("http")) {
            nextUrl = new URL(nextUrl, currentUrl).toString();
          }
        }
      }

      chain.push({
        url: currentUrl,
        status,
        redirect_type: redirectType,
        params,
      });

      if (!nextUrl || redirectType === "final") {
        break;
      }

      currentUrl = nextUrl;
      redirectCount++;
    } catch (error: any) {
      if (error.name === "AbortError") {
        chain.push({
          url: currentUrl,
          status: 0,
          redirect_type: "timeout",
          params: {},
        });
        break;
      }
      throw error;
    }
  }

  return chain;
}
