import { useEffect, useState } from 'react';
import { Activity, ChevronDown, ChevronUp, RefreshCw, TrendingUp, Link2, Calendar, Clock, Globe, Monitor, Smartphone, Tablet, Bot } from 'lucide-react';
import { supabase, SuffixRequest, Offer, OfferStatistics, UrlTrace } from '../lib/supabase';

interface OfferWithStats {
  offer: Offer;
  stats: OfferStatistics | null;
  recentRequests: SuffixRequest[];
  urlTraces: UrlTrace[];
}

export default function Analytics() {
  const [offersWithStats, setOffersWithStats] = useState<OfferWithStats[]>([]);
  const [expandedOffers, setExpandedOffers] = useState<Set<string>>(new Set());
  const [activeTab, setActiveTab] = useState<Record<string, 'suffix' | 'traces'>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAllData();
  }, []);

  const fetchAllData = async () => {
    setLoading(true);
    try {
      const { data: offers, error: offersError } = await supabase
        .from('offers')
        .select('*')
        .order('created_at', { ascending: false });

      if (offersError) throw offersError;

      const offersData: OfferWithStats[] = await Promise.all(
        (offers || []).map(async (offer) => {
          const { data: stats } = await supabase
            .from('offer_statistics')
            .select('*')
            .eq('offer_id', offer.id)
            .maybeSingle();

          const { data: requests } = await supabase
            .from('suffix_requests')
            .select('*')
            .eq('offer_id', offer.id)
            .order('requested_at', { ascending: false })
            .limit(10);

          const { data: traces } = await supabase
            .from('url_traces')
            .select('*')
            .eq('offer_id', offer.id)
            .order('visited_at', { ascending: false })
            .limit(100);

          return {
            offer,
            stats: stats || null,
            recentRequests: requests || [],
            urlTraces: traces || [],
          };
        })
      );

      setOffersWithStats(offersData);
    } catch (err) {
      console.error('Error fetching data:', err);
    } finally {
      setLoading(false);
    }
  };

  const toggleOffer = (offerId: string) => {
    const newExpanded = new Set(expandedOffers);
    if (newExpanded.has(offerId)) {
      newExpanded.delete(offerId);
    } else {
      newExpanded.add(offerId);
    }
    setExpandedOffers(newExpanded);
  };

  const formatNumber = (num: number) => {
    return num.toLocaleString();
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  const getRecencyColor = (lastRequestAt: string | null) => {
    if (!lastRequestAt) return 'bg-gray-400';

    const now = new Date();
    const lastRequest = new Date(lastRequestAt);
    const diffMs = now.getTime() - lastRequest.getTime();
    const diffHours = diffMs / (1000 * 60 * 60);

    if (diffHours < 1) return 'bg-green-500';
    if (diffHours < 24) return 'bg-yellow-500';
    return 'bg-gray-400';
  };

  const getRecencyText = (lastRequestAt: string | null) => {
    if (!lastRequestAt) return 'Never';

    const now = new Date();
    const lastRequest = new Date(lastRequestAt);
    const diffMs = now.getTime() - lastRequest.getTime();
    const diffMinutes = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffMinutes < 1) return 'Just now';
    if (diffMinutes < 60) return `${diffMinutes}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
  };

  const totalSuffixRequests = offersWithStats.reduce(
    (sum, item) => sum + (item.stats?.total_suffix_requests || 0),
    0
  );

  const totalTrackingHits = offersWithStats.reduce(
    (sum, item) => sum + (item.stats?.total_tracking_hits || 0),
    0
  );

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-2 mb-4">
            <Activity className="text-blue-600" size={24} />
            <h2 className="text-xl font-bold text-gray-900">Analytics Dashboard</h2>
          </div>
          <div className="text-center py-8 text-gray-500">Loading analytics...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Activity className="text-blue-600" size={24} />
            <h2 className="text-xl font-bold text-gray-900">Analytics Dashboard</h2>
          </div>
          <button
            onClick={fetchAllData}
            className="flex items-center gap-2 px-4 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors font-medium"
          >
            <RefreshCw size={16} />
            Refresh
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4 border border-blue-200">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="text-blue-600" size={20} />
              <h3 className="text-sm font-semibold text-blue-900">Total Offers</h3>
            </div>
            <p className="text-3xl font-bold text-blue-700">{formatNumber(offersWithStats.length)}</p>
          </div>

          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4 border border-green-200">
            <div className="flex items-center gap-2 mb-2">
              <Link2 className="text-green-600" size={20} />
              <h3 className="text-sm font-semibold text-green-900">Total Suffix Requests</h3>
            </div>
            <p className="text-3xl font-bold text-green-700">{formatNumber(totalSuffixRequests)}</p>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-4 border border-purple-200">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="text-purple-600" size={20} />
              <h3 className="text-sm font-semibold text-purple-900">Total Tracking Hits</h3>
            </div>
            <p className="text-3xl font-bold text-purple-700">{formatNumber(totalTrackingHits)}</p>
          </div>
        </div>

        {offersWithStats.length === 0 ? (
          <div className="text-center py-12 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
            <p className="text-gray-500">No offers yet. Create your first offer to start tracking analytics.</p>
          </div>
        ) : (
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Offers Overview</h3>
            {offersWithStats.map(({ offer, stats, recentRequests, urlTraces }) => {
              const isExpanded = expandedOffers.has(offer.id);
              const currentTab = activeTab[offer.id] || 'suffix';
              return (
                <div
                  key={offer.id}
                  className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow"
                >
                  <button
                    onClick={() => toggleOffer(offer.id)}
                    className="w-full bg-white hover:bg-gray-50 transition-colors"
                  >
                    <div className="p-4 flex items-center justify-between">
                      <div className="flex items-center gap-4 flex-1">
                        <div className={`w-3 h-3 rounded-full ${getRecencyColor(stats?.last_request_at || null)}`} />
                        <div className="text-left flex-1">
                          <div className="flex items-center gap-3">
                            <h4 className="text-base font-semibold text-gray-900">{offer.offer_name}</h4>
                            {offer.is_active ? (
                              <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs font-medium rounded">
                                Active
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs font-medium rounded">
                                Inactive
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-6 mt-2 text-sm text-gray-600">
                            <div className="flex items-center gap-1">
                              <Link2 size={14} />
                              <span className="font-medium">{formatNumber(stats?.total_suffix_requests || 0)}</span>
                              <span className="text-gray-500">suffix requests</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Activity size={14} />
                              <span className="font-medium">{formatNumber(stats?.total_tracking_hits || 0)}</span>
                              <span className="text-gray-500">tracking hits</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock size={14} />
                              <span className="text-gray-500">Last: {getRecencyText(stats?.last_request_at || null)}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="text-gray-400">
                        {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                      </div>
                    </div>
                  </button>

                  {isExpanded && (
                    <div className="bg-gray-50 border-t border-gray-200 p-4">
                      <div className="flex gap-2 mb-4 border-b border-gray-300">
                        <button
                          onClick={() => setActiveTab({ ...activeTab, [offer.id]: 'suffix' })}
                          className={`px-4 py-2 text-sm font-medium transition-colors ${
                            currentTab === 'suffix'
                              ? 'border-b-2 border-blue-600 text-blue-600'
                              : 'text-gray-600 hover:text-gray-900'
                          }`}
                        >
                          Suffix Requests ({recentRequests.length})
                        </button>
                        <button
                          onClick={() => setActiveTab({ ...activeTab, [offer.id]: 'traces' })}
                          className={`px-4 py-2 text-sm font-medium transition-colors ${
                            currentTab === 'traces'
                              ? 'border-b-2 border-blue-600 text-blue-600'
                              : 'text-gray-600 hover:text-gray-900'
                          }`}
                        >
                          URL Traces ({urlTraces.length})
                        </button>
                      </div>

                      {currentTab === 'suffix' && (
                        <>
                          <h5 className="text-sm font-semibold text-gray-700 mb-3">
                            Last 10 Suffix Requests
                          </h5>
                          {recentRequests.length === 0 ? (
                            <div className="text-center py-6 text-gray-500 text-sm">
                              No suffix requests yet for this offer
                            </div>
                          ) : (
                            <div className="overflow-x-auto">
                              <table className="w-full text-xs">
                                <thead>
                                  <tr className="border-b border-gray-300">
                                    <th className="text-left py-2 px-3 font-semibold text-gray-700">Time</th>
                                    <th className="text-left py-2 px-3 font-semibold text-gray-700">Suffix</th>
                                    <th className="text-left py-2 px-3 font-semibold text-gray-700">IP Address</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {recentRequests.map((request) => (
                                    <tr key={request.id} className="border-b border-gray-200 hover:bg-white">
                                      <td className="py-2 px-3">
                                        <div className="flex items-center gap-1 text-gray-600">
                                          <Calendar size={12} />
                                          {formatDate(request.requested_at)}
                                        </div>
                                      </td>
                                      <td className="py-2 px-3">
                                        <code className="px-2 py-1 bg-white text-gray-800 rounded text-xs font-mono border border-gray-200">
                                          {request.suffix_returned || '(empty)'}
                                        </code>
                                      </td>
                                      <td className="py-2 px-3">
                                        <div className="flex items-center gap-1 text-gray-600">
                                          <Globe size={12} />
                                          {request.ip_address || 'N/A'}
                                        </div>
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          )}
                        </>
                      )}

                      {currentTab === 'traces' && (
                        <>
                          <h5 className="text-sm font-semibold text-gray-700 mb-3">
                            URL Tracking Hits (Last 100)
                          </h5>
                          {urlTraces.length === 0 ? (
                            <p className="text-sm text-gray-500 text-center py-4">
                              No tracking hits recorded yet
                            </p>
                          ) : (
                            <div className="space-y-3">
                              {urlTraces.map((trace) => {
                                const getDeviceIcon = (deviceType: string) => {
                                  switch (deviceType.toLowerCase()) {
                                    case 'mobile': return <Smartphone size={16} />;
                                    case 'tablet': return <Tablet size={16} />;
                                    case 'bot': return <Bot size={16} />;
                                    default: return <Monitor size={16} />;
                                  }
                                };

                                const getDeviceColor = (deviceType: string) => {
                                  switch (deviceType.toLowerCase()) {
                                    case 'mobile': return 'bg-blue-100 text-blue-700';
                                    case 'tablet': return 'bg-purple-100 text-purple-700';
                                    case 'bot': return 'bg-gray-100 text-gray-700';
                                    default: return 'bg-green-100 text-green-700';
                                  }
                                };

                                return (
                                  <div key={trace.id} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                                    <div className="flex items-start justify-between mb-2">
                                      <div className="flex items-center gap-2">
                                        <span className={`px-2 py-1 rounded text-xs font-medium flex items-center gap-1 ${getDeviceColor(trace.device_type)}`}>
                                          {getDeviceIcon(trace.device_type)}
                                          {trace.device_type}
                                        </span>
                                        <span className="text-xs text-gray-500">
                                          {new Date(trace.visited_at).toLocaleString()}
                                        </span>
                                      </div>
                                    </div>

                                    <div className="space-y-2 text-sm">
                                      <div className="flex items-center gap-2">
                                        <Globe size={14} className="text-gray-400" />
                                        <span className="text-gray-600">IP:</span>
                                        <span className="font-mono text-gray-900">{trace.visitor_ip}</span>
                                      </div>

                                      {trace.country && (
                                        <div className="flex items-center gap-2">
                                          <Globe size={14} className="text-gray-400" />
                                          <span className="text-gray-600">Location:</span>
                                          <span className="text-gray-900">
                                            {trace.city ? `${trace.city}, ` : ''}{trace.country}
                                          </span>
                                        </div>
                                      )}

                                      {trace.referrer && (
                                        <div className="flex items-center gap-2">
                                          <Link2 size={14} className="text-gray-400" />
                                          <span className="text-gray-600">Referrer:</span>
                                          <span className="font-mono text-gray-900 truncate">{trace.referrer}</span>
                                        </div>
                                      )}

                                      {trace.query_params && Object.keys(trace.query_params).length > 0 && (
                                        <div>
                                          <span className="text-gray-600 text-xs font-semibold mb-1 block">Query Parameters:</span>
                                          <div className="bg-white rounded p-2 space-y-1">
                                            {Object.entries(trace.query_params).map(([key, value]) => (
                                              <div key={key} className="flex gap-2 text-xs font-mono">
                                                <span className="font-semibold text-gray-700">{key}:</span>
                                                <span className="text-gray-900 break-all">{String(value)}</span>
                                              </div>
                                            ))}
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
