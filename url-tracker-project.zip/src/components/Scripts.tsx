import { useState } from 'react';
import { Copy, CheckCircle, FileCode, Code2, FileText } from 'lucide-react';

export default function Scripts() {
  const [copiedScript, setCopiedScript] = useState<string | null>(null);
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;

  const copyToClipboard = (text: string, scriptName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedScript(scriptName);
    setTimeout(() => setCopiedScript(null), 2000);
  };

  const googleAdsScript = `// ============================================
// RATE CONTROL CONFIGURATION
// ============================================
// Adjust DELAY_MS to control API call speed:
// - 0 = No delay (fastest, use for testing)
// - 1000 = 1 second delay (60 calls/minute)
// - 2000 = 2 second delay (30 calls/minute)
// - 5000 = 5 second delay (12 calls/minute)
var DELAY_MS = 1000;

// Replace 'OFFER_NAME' with your actual offer name
var OFFER_NAME = 'OFFER_NAME';

// ============================================
// MAIN FUNCTION
// ============================================
function getTrackingUrl() {
  // Add delay to control API call rate
  if (DELAY_MS > 0) {
    Utilities.sleep(DELAY_MS);
  }

  var url = '${supabaseUrl}/functions/v1/get-suffix?offer_name=' + encodeURIComponent(OFFER_NAME);

  var options = {
    'method': 'get',
    'muteHttpExceptions': true
  };

  try {
    var response = UrlFetchApp.fetch(url, options);
    var json = JSON.parse(response.getContentText());

    if (json.success && json.suffix) {
      return json.final_url + '?' + json.suffix;
    }
  } catch (e) {
    Logger.log('Error fetching URL: ' + e.toString());
  }

  return '';
}

function main() {
  var trackingUrl = getTrackingUrl();
  Logger.log('Tracking URL: ' + trackingUrl);

  // Use this URL in your ad customizers
  return trackingUrl;
}`;

  const trackingTemplate = `${supabaseUrl}/functions/v1/get-suffix?offer_name=OFFER_NAME&redirect=true`;

  const jsSnippet = `<script>
(function() {
  // Replace 'OFFER_NAME' with your actual offer name
  var offerName = 'OFFER_NAME';

  var apiUrl = '${supabaseUrl}/functions/v1/get-suffix?offer_name=' + encodeURIComponent(offerName);

  fetch(apiUrl)
    .then(function(response) { return response.json(); })
    .then(function(data) {
      if (data.success && data.suffix) {
        var redirectUrl = data.final_url + '?' + data.suffix;
        window.location.href = redirectUrl;
      } else {
        console.error('Failed to get tracking parameters');
      }
    })
    .catch(function(error) {
      console.error('Error:', error);
    });
})();
</script>`;

  const trackHitPixel = `<!-- Replace 'OFFER_NAME' with your actual offer name -->
<img src="${supabaseUrl}/functions/v1/track-hit?offer=OFFER_NAME" width="1" height="1" style="display:none" />`;

  const trackHitRedirect = `<!-- Replace 'OFFER_NAME' with your actual offer name -->
<a href="${supabaseUrl}/functions/v1/track-hit?offer=OFFER_NAME&redirect=true">
  Click Here
</a>`;

  const curlExample = `# Get Suffix (with redirect)
curl "${supabaseUrl}/functions/v1/get-suffix?offer_name=OFFER_NAME&redirect=true"

# Track Hit (with redirect)
curl "${supabaseUrl}/functions/v1/track-hit?offer=OFFER_NAME&redirect=true"

# Trace Redirects
curl -X POST "${supabaseUrl}/functions/v1/trace-redirects" \\
  -H "Authorization: Bearer YOUR_ANON_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "url": "https://example.com/tracking-url",
    "max_redirects": 20,
    "timeout_ms": 30000
  }'`;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Integration Scripts</h2>
        <p className="text-gray-600 mt-1">
          Ready-to-use scripts for Google Ads, landing pages, and tracking. Replace 'OFFER_NAME' with your actual offer name.
        </p>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-sm text-blue-900">
          <strong>Important:</strong> Replace 'OFFER_NAME' in all scripts with your actual offer name from the Offers page.
          The scripts will fetch fresh parameters on each call.
        </p>
      </div>

      <div className="grid gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="bg-gray-50 px-6 py-4 border-b border-gray-200 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Code2 className="text-blue-600" size={24} />
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Google Ads Script (with Rate Control)</h3>
                <p className="text-sm text-gray-600">
                  Built-in delay mechanism to control API call speed. Configure DELAY_MS at the top.
                </p>
              </div>
            </div>
            <button
              onClick={() => copyToClipboard(googleAdsScript, 'google-ads')}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              {copiedScript === 'google-ads' ? (
                <>
                  <CheckCircle size={18} />
                  Copied
                </>
              ) : (
                <>
                  <Copy size={18} />
                  Copy
                </>
              )}
            </button>
          </div>
          <div className="p-6 space-y-4">
            <pre className="bg-gray-900 text-gray-100 text-sm p-4 rounded overflow-x-auto">
              {googleAdsScript}
            </pre>
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <h4 className="font-semibold text-yellow-900 mb-2">Rate Control Configuration</h4>
              <div className="text-sm text-yellow-800 space-y-2">
                <p>
                  The <code className="bg-yellow-100 px-1 py-0.5 rounded">DELAY_MS</code> variable controls how fast the script calls your API endpoint.
                </p>
                <ul className="list-disc ml-5 space-y-1">
                  <li><strong>0 ms</strong> - No delay (fastest, for testing)</li>
                  <li><strong>1000 ms</strong> - 1 second between calls (60 calls/min)</li>
                  <li><strong>2000 ms</strong> - 2 seconds between calls (30 calls/min)</li>
                  <li><strong>5000 ms</strong> - 5 seconds between calls (12 calls/min)</li>
                </ul>
                <p className="pt-1">
                  Adjust based on your API limits and campaign requirements. Higher delays = slower API calls = lower server load.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="bg-gray-50 px-6 py-4 border-b border-gray-200 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <FileCode className="text-green-600" size={24} />
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Tracking Template (Direct)</h3>
                <p className="text-sm text-gray-600">
                  Paste directly into Google Ads tracking template field
                </p>
              </div>
            </div>
            <button
              onClick={() => copyToClipboard(trackingTemplate, 'tracking-template')}
              className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              {copiedScript === 'tracking-template' ? (
                <>
                  <CheckCircle size={18} />
                  Copied
                </>
              ) : (
                <>
                  <Copy size={18} />
                  Copy
                </>
              )}
            </button>
          </div>
          <div className="p-6">
            <pre className="bg-gray-900 text-gray-100 text-sm p-4 rounded overflow-x-auto">
              {trackingTemplate}
            </pre>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="bg-gray-50 px-6 py-4 border-b border-gray-200 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <FileText className="text-purple-600" size={24} />
              <div>
                <h3 className="text-lg font-semibold text-gray-900">JavaScript Redirect Snippet</h3>
                <p className="text-sm text-gray-600">
                  Add to landing page for client-side redirect with fresh parameters
                </p>
              </div>
            </div>
            <button
              onClick={() => copyToClipboard(jsSnippet, 'js-snippet')}
              className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              {copiedScript === 'js-snippet' ? (
                <>
                  <CheckCircle size={18} />
                  Copied
                </>
              ) : (
                <>
                  <Copy size={18} />
                  Copy
                </>
              )}
            </button>
          </div>
          <div className="p-6">
            <pre className="bg-gray-900 text-gray-100 text-sm p-4 rounded overflow-x-auto">
              {jsSnippet}
            </pre>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
            <div className="flex items-center gap-3">
              <FileCode className="text-orange-600" size={24} />
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Tracking Pixel & Redirect Link</h3>
                <p className="text-sm text-gray-600">
                  Use for visitor tracking (pixel) or redirect links
                </p>
              </div>
            </div>
          </div>
          <div className="p-6 space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium text-gray-700">Tracking Pixel (No Redirect)</p>
                <button
                  onClick={() => copyToClipboard(trackHitPixel, 'pixel')}
                  className="flex items-center gap-2 px-3 py-1.5 text-sm bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                >
                  {copiedScript === 'pixel' ? (
                    <>
                      <CheckCircle size={16} />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy size={16} />
                      Copy
                    </>
                  )}
                </button>
              </div>
              <pre className="bg-gray-900 text-gray-100 text-sm p-4 rounded overflow-x-auto">
                {trackHitPixel}
              </pre>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium text-gray-700">Redirect Link</p>
                <button
                  onClick={() => copyToClipboard(trackHitRedirect, 'redirect-link')}
                  className="flex items-center gap-2 px-3 py-1.5 text-sm bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                >
                  {copiedScript === 'redirect-link' ? (
                    <>
                      <CheckCircle size={16} />
                      Copied
                    </>
                  ) : (
                    <>
                      <Copy size={16} />
                      Copy
                    </>
                  )}
                </button>
              </div>
              <pre className="bg-gray-900 text-gray-100 text-sm p-4 rounded overflow-x-auto">
                {trackHitRedirect}
              </pre>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="bg-gray-50 px-6 py-4 border-b border-gray-200 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <FileCode className="text-gray-600" size={24} />
              <div>
                <h3 className="text-lg font-semibold text-gray-900">cURL Examples</h3>
                <p className="text-sm text-gray-600">
                  API testing and integration examples
                </p>
              </div>
            </div>
            <button
              onClick={() => copyToClipboard(curlExample, 'curl')}
              className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
            >
              {copiedScript === 'curl' ? (
                <>
                  <CheckCircle size={18} />
                  Copied
                </>
              ) : (
                <>
                  <Copy size={18} />
                  Copy
                </>
              )}
            </button>
          </div>
          <div className="p-6">
            <pre className="bg-gray-900 text-gray-100 text-sm p-4 rounded overflow-x-auto">
              {curlExample}
            </pre>
          </div>
        </div>
      </div>

      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <h4 className="font-semibold text-yellow-900 mb-2">API Endpoints</h4>
        <div className="space-y-2 text-sm text-yellow-800">
          <div>
            <strong>GET /functions/v1/get-suffix</strong>
            <p className="ml-4">Fetches fresh tracking parameters for an offer</p>
            <p className="ml-4 text-xs">Parameters: offer_name (required), redirect (optional)</p>
          </div>
          <div>
            <strong>GET /functions/v1/track-hit</strong>
            <p className="ml-4">Tracks visitor hits and optionally redirects</p>
            <p className="ml-4 text-xs">Parameters: offer (required), redirect (optional)</p>
          </div>
          <div>
            <strong>POST /functions/v1/trace-redirects</strong>
            <p className="ml-4">Traces complete redirect chain with geo-targeting support</p>
            <p className="ml-4 text-xs">Body: url, proxy_url, max_redirects, timeout_ms, user_agent</p>
          </div>
        </div>
      </div>
    </div>
  );
}
