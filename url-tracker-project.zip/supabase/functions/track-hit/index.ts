import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

function detectDeviceType(userAgent: string): string {
  const ua = userAgent.toLowerCase();

  if (ua.includes('bot') || ua.includes('crawler') || ua.includes('spider')) {
    return 'bot';
  }
  if (ua.includes('mobile') || ua.includes('android') || ua.includes('iphone')) {
    return 'mobile';
  }
  if (ua.includes('tablet') || ua.includes('ipad')) {
    return 'tablet';
  }
  return 'desktop';
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const url = new URL(req.url);
    const offerName = url.searchParams.get('offer');
    const redirect = url.searchParams.get('redirect') === 'true';

    if (!offerName) {
      return new Response(
        JSON.stringify({ error: 'offer parameter is required' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const { data: offer, error: offerError } = await supabase
      .from('offers')
      .select('*')
      .eq('offer_name', offerName)
      .eq('is_active', true)
      .maybeSingle();

    if (offerError || !offer) {
      return new Response(
        JSON.stringify({ error: 'Offer not found or inactive' }),
        {
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const visitorIp = req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || 'unknown';
    const userAgent = req.headers.get('user-agent') || 'unknown';
    const referrer = req.headers.get('referer') || req.headers.get('referrer') || '';
    const deviceType = detectDeviceType(userAgent);

    const queryParams: Record<string, string> = {};
    url.searchParams.forEach((value, key) => {
      if (key !== 'offer' && key !== 'redirect') {
        queryParams[key] = value;
      }
    });

    await supabase.from('url_traces').insert({
      offer_id: offer.id,
      visitor_ip: visitorIp,
      user_agent: userAgent,
      referrer: referrer,
      device_type: deviceType,
      final_url: offer.final_url,
      query_params: queryParams,
      visited_at: new Date().toISOString(),
    });

    const { data: currentStats } = await supabase
      .from('offer_statistics')
      .select('*')
      .eq('offer_id', offer.id)
      .maybeSingle();

    const newStats = {
      offer_id: offer.id,
      total_suffix_requests: currentStats?.total_suffix_requests || 0,
      total_tracking_hits: (currentStats?.total_tracking_hits || 0) + 1,
      last_request_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    await supabase
      .from('offer_statistics')
      .upsert(newStats, { onConflict: 'offer_id' });

    if (redirect) {
      return new Response(null, {
        status: 302,
        headers: {
          ...corsHeaders,
          'Location': offer.final_url,
        },
      });
    }

    return new Response(
      JSON.stringify({
        success: true,
        offer_name: offer.offer_name,
        tracked: true,
        timestamp: new Date().toISOString(),
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error: any) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error', message: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
