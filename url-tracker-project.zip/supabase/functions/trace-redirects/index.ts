import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface RedirectStep {
  url: string;
  status: number;
  redirect_type: 'http' | 'meta' | 'javascript' | 'final' | 'error';
  method: string;
  headers?: Record<string, string>;
  params?: Record<string, string>;
  html_snippet?: string;
  error?: string;
  timing_ms?: number;
}

interface TraceRequest {
  url: string;
  proxy_url?: string;
  max_redirects?: number;
  timeout_ms?: number;
  user_agent?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { url, proxy_url, max_redirects = 20, timeout_ms = 30000, user_agent } = await req.json() as TraceRequest;

    if (!url) {
      throw new Error('URL is required');
    }

    const chain: RedirectStep[] = [];
    let currentUrl = url;
    let redirectCount = 0;
    const visitedUrls = new Set<string>();

    // Custom headers
    const customHeaders: Record<string, string> = {
      'User-Agent': user_agent || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.9',
      'Accept-Encoding': 'gzip, deflate, br',
      'Connection': 'keep-alive',
      'Upgrade-Insecure-Requests': '1',
    };

    while (redirectCount < max_redirects) {
      // Detect redirect loops
      if (visitedUrls.has(currentUrl)) {
        chain.push({
          url: currentUrl,
          status: 0,
          redirect_type: 'error',
          method: 'loop_detected',
          error: 'Redirect loop detected',
        });
        break;
      }
      visitedUrls.add(currentUrl);

      const startTime = Date.now();
      let step: RedirectStep;

      try {
        // Fetch with timeout and optional proxy
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeout_ms);

        const fetchOptions: RequestInit = {
          method: 'GET',
          headers: customHeaders,
          redirect: 'manual',
          signal: controller.signal,
        };

        // Note: Deno Deploy doesn't support HTTP proxies directly via fetch
        // For production, you'd need a proxy service or run this locally
        let response: Response;
        if (proxy_url) {
          // Proxy support would require a proxy service endpoint
          // For now, we'll note this in the response
          response = await fetch(currentUrl, fetchOptions);
        } else {
          response = await fetch(currentUrl, fetchOptions);
        }

        clearTimeout(timeoutId);
        const timing = Date.now() - startTime;

        // Extract headers
        const responseHeaders: Record<string, string> = {};
        response.headers.forEach((value, key) => {
          responseHeaders[key.toLowerCase()] = value;
        });

        // Extract URL parameters
        const urlObj = new URL(currentUrl);
        const params: Record<string, string> = {};
        urlObj.searchParams.forEach((value, key) => {
          params[key] = value;
        });

        // Check for HTTP redirect (3xx)
        if (response.status >= 300 && response.status < 400) {
          const location = response.headers.get('location');
          if (!location) {
            step = {
              url: currentUrl,
              status: response.status,
              redirect_type: 'error',
              method: 'http',
              headers: responseHeaders,
              params,
              error: 'No location header in redirect response',
              timing_ms: timing,
            };
            chain.push(step);
            break;
          }

          // Resolve relative URLs
          const nextUrl = new URL(location, currentUrl).toString();

          step = {
            url: currentUrl,
            status: response.status,
            redirect_type: 'http',
            method: 'location_header',
            headers: responseHeaders,
            params,
            timing_ms: timing,
          };
          chain.push(step);

          currentUrl = nextUrl;
          redirectCount++;
          continue;
        }

        // For 2xx responses, check HTML content for meta refresh and JavaScript redirects
        if (response.status >= 200 && response.status < 300) {
          const contentType = response.headers.get('content-type') || '';
          
          if (contentType.includes('text/html')) {
            const html = await response.text();
            
            // Check for meta refresh
            const metaRefreshMatch = html.match(/<meta[^>]*http-equiv=["']?refresh["']?[^>]*content=["']?\d+;\s*url=([^"'>\s]+)["']?[^>]*>/i);
            if (metaRefreshMatch) {
              const nextUrl = new URL(metaRefreshMatch[1].trim(), currentUrl).toString();
              
              step = {
                url: currentUrl,
                status: response.status,
                redirect_type: 'meta',
                method: 'meta_refresh',
                headers: responseHeaders,
                params,
                html_snippet: metaRefreshMatch[0].substring(0, 200),
                timing_ms: timing,
              };
              chain.push(step);

              currentUrl = nextUrl;
              redirectCount++;
              continue;
            }

            // Check for JavaScript redirects (multiple patterns)
            const jsRedirectPatterns = [
              /window\.location\.href\s*=\s*["']([^"']+)["']/i,
              /window\.location\.replace\(["']([^"']+)["']\)/i,
              /window\.location\s*=\s*["']([^"']+)["']/i,
              /location\.href\s*=\s*["']([^"']+)["']/i,
              /location\.replace\(["']([^"']+)["']\)/i,
              /document\.location\.href\s*=\s*["']([^"']+)["']/i,
              /top\.location\.href\s*=\s*["']([^"']+)["']/i,
            ];

            for (const pattern of jsRedirectPatterns) {
              const jsMatch = html.match(pattern);
              if (jsMatch) {
                try {
                  const nextUrl = new URL(jsMatch[1].trim(), currentUrl).toString();
                  
                  step = {
                    url: currentUrl,
                    status: response.status,
                    redirect_type: 'javascript',
                    method: 'js_redirect',
                    headers: responseHeaders,
                    params,
                    html_snippet: jsMatch[0].substring(0, 200),
                    timing_ms: timing,
                  };
                  chain.push(step);

                  currentUrl = nextUrl;
                  redirectCount++;
                  break;
                } catch (e) {
                  // Invalid URL in JavaScript, continue to next pattern
                  continue;
                }
              }
            }

            // If we found a JS redirect, continue the loop
            if (step && step.redirect_type === 'javascript') {
              continue;
            }
          }

          // No more redirects found - this is the final destination
          step = {
            url: currentUrl,
            status: response.status,
            redirect_type: 'final',
            method: 'final_destination',
            headers: responseHeaders,
            params,
            timing_ms: timing,
          };
          chain.push(step);
          break;
        }

        // Handle error responses (4xx, 5xx)
        step = {
          url: currentUrl,
          status: response.status,
          redirect_type: 'error',
          method: 'http',
          headers: responseHeaders,
          params,
          error: `HTTP ${response.status} ${response.statusText}`,
          timing_ms: timing,
        };
        chain.push(step);
        break;

      } catch (error: any) {
        // Handle fetch errors (timeout, network error, etc.)
        step = {
          url: currentUrl,
          status: 0,
          redirect_type: 'error',
          method: 'fetch_error',
          error: error.message || 'Network error',
          timing_ms: Date.now() - startTime,
        };
        chain.push(step);
        break;
      }
    }

    // Check if we hit max redirects
    if (redirectCount >= max_redirects) {
      chain.push({
        url: 'max_redirects_reached',
        status: 0,
        redirect_type: 'error',
        method: 'limit',
        error: `Maximum redirect limit (${max_redirects}) reached`,
      });
    }

    // Calculate total timing
    const totalTiming = chain.reduce((sum, step) => sum + (step.timing_ms || 0), 0);

    return new Response(
      JSON.stringify({
        success: true,
        chain,
        total_steps: chain.length,
        total_timing_ms: totalTiming,
        final_url: chain.length > 0 ? chain[chain.length - 1].url : url,
        proxy_used: !!proxy_url,
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      },
    );

  } catch (error: any) {
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'Failed to trace redirects',
      }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      },
    );
  }
});